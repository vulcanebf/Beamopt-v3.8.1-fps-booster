@echo off
title BeamOpt v3.8.1 Native Bridge
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BeamOpt-NativeBridge.ps1" %*
pause
