@echo off
title BeamOpt v3.9.0 Native Bridge - Runtime Pattern Scan
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BeamOpt-NativeBridge.ps1" %*
pause
