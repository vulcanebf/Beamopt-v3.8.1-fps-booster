# BeamOpt

BeamOpt is a performance optimization mod for **BeamNG.drive**, developed and benchmarked on **0.39.4.0.20972 Win64**. It reduces the cost of mirrors, vehicle reflections, planar reflections, and PSSM world shadows while preserving the dedicated vehicle-shadow path.

The mod uses a normal BeamNG Lua/UI component plus a Windows PowerShell native bridge. All native modifications are **RAM-only** and are guarded for the exact tested BeamNG executable build.

> **Primary tested build:** BeamNG.drive `0.39.4.0.20972` Win64  
> **Tested renderers:** Direct3D 11, Direct3D 12, Vulkan  
> **Recommended renderer for maximum gain:** Direct3D 11

---

## Performance results

Performance varies by map, vehicle, camera, graphics settings, CPU/GPU balance, and renderer. These are measured results from the development/test system, not guaranteed results for every PC.

| Renderer / view | BeamOpt off | BeamOpt on | Gain |
|---|---:|---:|---:|
| **DX11, interior** | 24.5 FPS | ~36 FPS | **+11.5 FPS / +46.9%** |
| **DX11, exterior** | 32.2–32.5 FPS | 41–44 FPS | **~+26% to +37%** |
| **DX12** | 35.8 FPS | 38.6 FPS | **+2.8 FPS / +7.8%** |
| **Vulkan** | 33.5 FPS | 35.5 FPS | **+2.0 FPS / +6.0%** |

The largest measured improvement was on **Direct3D 11**, especially in interior view where native mirrors and shadows were a major CPU/render-thread cost.

### Shadow-rate testing

Selective world-shadow rates of **1/2, 1/3, 1/4, and 1/5** are available.

In current testing:

- **1/2** is the recommended setting.
- **1/5 remained visually stable** in the tested scene.
- Going below 1/2 did **not** produce a meaningful additional FPS increase in that scene.
- Dedicated vehicle shadows continue updating at full rate while world PSSM shadows are selectively scheduled.

This means 1/2 currently provides most of the available shadow-scheduling benefit without unnecessarily lowering world-shadow update frequency.

---

## Main optimizations

### Selective PSSM world-shadow scheduling

BeamOpt does not simply skip the entire shadow pass.

It synchronizes the main world-shadow atlas clear and world-cascade render at the selected rate while keeping the dedicated `VehicleShadowTex` path running at full rate.

Available world-shadow rates:

- Native
- 1/2
- 1/3
- 1/4
- 1/5

This avoids the severe black/flickering shadow failures that occurred with early whole-pass frame skipping.

### PSSM 6.0 fast path

BeamOpt includes the recovered **PSSM 6.0** optimization.

This changes the native PSSM behavior by holding the recovered runtime value at `6.0` and suppressing the native writer that normally replaces it.

During development this produced one of the largest CPU-side improvements. CPU wait time was observed dropping dramatically in some scenes.

Enabled by default.

### World caster mask 0x100

The normal world PSSM cascade caster mask is changed from `0x300` to `0x100`.

This produced an additional measured performance improvement while retaining the important tested world shadows.

Enabled by default.

### Optional 3-split PSSM mode

BeamNG normally uses 4 PSSM splits.

BeamOpt includes an optional **3-split** mode for an additional smaller performance reduction in PSSM work.

It is disabled by default because the final recommended configuration was validated with the native 4-split layout.

### Mirror scheduling

Vehicle mirror CubeReflectors can run at:

- Native
- 1/2
- 1/3
- 1/4
- 1/5

Mirror updates are phase-staggered to avoid updating every reflector on the same frame.

### Automatic interior/exterior mirror profile

BeamOpt 3.9.1 uses **BeamNG's own camera-mode change event** as the authoritative view detector. It no longer decides interior/exterior state from the number of mirror reflector objects.

- **Driver/cockpit camera:** treated as **interior view**
- **Orbit/chase/external/hood and other non-cockpit cameras:** treated as **exterior view**

The mirror buttons store the user's **interior preference**.

Example:

1. Set mirrors to **1/2** in first-person/interior view.
2. Switch to third-person.
3. BeamOpt detects 0 mirrors and leaves the mirror path effectively Native.
4. Return to first person.
5. Mirrors are detected again and the saved **1/2** preference is restored automatically.

The automatic view profile is enabled by default.

### Vehicle body reflections

Vehicle body/dynamic CubeReflector updates can be reduced independently from mirrors.

Available rates:

- Native
- 1/2
- 1/3
- 1/4
- 1/5

### Planar reflections

PlaneReflector updates can also be scheduled independently:

- Native
- 1/2
- 1/3
- 1/4
- 1/5

### Low-I/O bridge

The BeamOpt control/status bridge uses a low-frequency file interface instead of constantly polling/writing.

Current cadence is approximately **0.5 Hz**, which produced a measurable improvement during development.

---

## Recommended settings

For the current tested build:

```text
Vehicle Mirrors:          1/2 interior preference
Auto mirror profile:      ON
Vehicle Body Reflections: test 1/2 if desired
Planar Reflections:       test 1/2 if desired

World Shadows:            1/2
PSSM 6.0:                 ON
World Caster Mask 0x100:  ON
3-Split PSSM:             OFF initially
```

Start from this configuration, then test the reflection controls individually for your vehicle/map.

---

# Installation


## GitHub release package layout

The downloadable release is also named `BeamOpt_3.9.2.zip`. Extract that outer ZIP first. It contains:

```text
BeamOpt_3.9.2.zip          <- place this inner ZIP in your BeamNG mods folder
BeamOpt-NativeBridge.ps1
Start-BeamOpt-NativeBridge.cmd
README.md
GITHUB_DESCRIPTION.txt
SHA256SUMS.txt
```

The **inner** `BeamOpt_3.9.2.zip` is the actual BeamNG mod. Do not extract the inner mod ZIP when installing it.


## Recommended install location

I recommend keeping the BeamNG user folder somewhere easy to access, such as on the **Desktop**, and placing BeamOpt in that user folder's `mods` directory.

Example layout:

```text
Desktop
└── BeamNG.drive
    └── mods
        └── BeamOpt_3.9.2.zip
```

If your BeamNG user folder is somewhere else, use that folder's normal `mods` directory instead.

You can find or move the BeamNG user folder through the BeamNG launcher/user-folder management options.

## 1. Install the BeamNG mod

Place:

```text
BeamOpt_3.9.2.zip
```

directly in the active BeamNG user `mods` folder.

Do **not** unpack the BeamNG mod ZIP unless you are intentionally developing/editing it.

## 2. Install the native bridge

Extract the standalone bridge bundle somewhere convenient, for example:

```text
Desktop\BeamOpt Bridge\
```

The bridge folder should contain:

```text
BeamOpt-NativeBridge.ps1
Start-BeamOpt-NativeBridge.cmd
```

Keep those two files together.

## 3. Start BeamNG

Launch BeamNG.drive normally.

BeamOpt was developed and benchmarked on:

```text
0.39.4.0.20972
```

The bridge no longer hard-blocks other BeamNG versions by executable version or file size. Instead, each native optimization still validates the expected machine-code bytes, signatures, vtable targets, and/or runtime state before it patches anything.

A later BeamNG version may therefore work without a BeamOpt update if the relevant native layout is unchanged. If BeamNG moves or rewrites a target, that optimization should refuse to install rather than blindly patch mismatched bytes.

Forward compatibility is **best-effort, not guaranteed**.

## 4. Start the BeamOpt native bridge

After BeamNG is running, run:

```text
Start-BeamOpt-NativeBridge.cmd
```

A PowerShell window should remain open and report the bridge status.

If Windows displays a security prompt, remember that this bridge opens the BeamNG process and modifies runtime memory. Review the source before running it if desired.

## 5. Add the BeamOpt UI app

In BeamNG:

1. Open the UI Apps editor.
2. Find **BeamOpt**.
3. Add it to the current UI layout.
4. Use the BeamOpt panel to select mirror, reflection, shadow, and PSSM settings.

---

# Normal shutdown

Before closing the bridge, press:

```text
Q
```

in the PowerShell bridge window.

BeamOpt will attempt to restore every native modification and verify restoration.

All native changes are RAM-only. A complete BeamNG process exit also clears them.

If the bridge is force-closed, crashes, or reports that restoration failed, fully exit BeamNG before starting another BeamOpt/native test session.

---

# Important compatibility notes

## BeamNG version compatibility

BeamOpt was reverse-engineered and fully tested on:

```text
BeamNG.drive 0.39.4.0.20972 Win64
```

BeamOpt 3.9.0 goes further than simply removing the version lockout: the bridge now **pattern-scans the active BeamNG executable at runtime** instead of using the recovered 0.39.4 RVAs as live patch addresses.

BeamOpt still uses recovered native RVAs, so compatibility with every BeamNG update cannot be guaranteed. Each optimization retains its local safety checks—expected native bytes/signatures, vtable targets, and runtime sanity checks—and refuses to patch when those checks do not match.

In practice:

- a later build with the same relevant native layout may work normally;
- if only some targets changed, only the compatible optimizations may work;
- a major update that relocates or rewrites these functions will require BeamOpt to be remapped.

The remaining signature/byte checks are intentional and should not be removed: they prevent version-flexible mode from becoming blind memory patching.


### Runtime pattern scanner

BeamOpt 3.9.0 resolves its native targets from the executable that is actually running:

- reflector-manager singleton: located from a wildcard registration-helper signature and its RIP-relative global reference;
- CubeReflector / PlaneReflector: identified from the live objects' MSVC RTTI, then their live vtable slots are used;
- selective PSSM scheduler: world-loop and atlas-clear sites are located from wildcard instruction patterns, with branch targets decoded from the matched machine code;
- PSSM 6.0: the split-distribution code is scanned first, the runtime float is recovered from its RIP-relative reference, and the matching writer is found by its reference to that same float;
- world caster mask and optional 3-split mode: resolved from local instruction signatures.

The scanner reads the active `BeamNG.drive.x64.exe` PE sections and derives the current RVAs. It does **not** scan for the old hard-coded addresses.

Pattern scanning improves update resilience when functions are merely relocated. It cannot automatically compensate for a major BeamNG rewrite that changes the underlying machine-code structure, object layouts, vtable slot meanings, or PSSM algorithm. In those cases the affected optimization will fail its pattern/native-byte validation and needs a new signature.

## Renderer compatibility

The current implementation has been tested successfully with:

- Direct3D 11
- Direct3D 12
- Vulkan

The optimization gain is renderer-dependent.

Measured results:

```text
DX11:   ~+47% in the tested interior case
DX12:   ~+8%
Vulkan: ~+6%
```

DX11 currently benefits the most from BeamOpt on the development system.

## Do not run old experimental hooks simultaneously

Do not combine the release bridge with old standalone development scripts that patch the same BeamNG functions.

Before switching from development scripts to the packaged mod:

1. Press Q in every standalone test window.
2. Close them.
3. If unsure, fully exit BeamNG.
4. Relaunch BeamNG.
5. Run only the BeamOpt bridge.

---

# What was tested and rejected

A number of ideas were tested during development and intentionally not used as final/default optimizations.

### Mirror face-count cap

Vehicle mirrors and dynamic reflections were mapped, but reducing the selected cube-face count did not provide enough useful performance/quality benefit to keep.

### Reflection resolution reduction

Native values observed during testing included approximately:

```text
Vehicle mirrors:          512
Vehicle body reflection:  128
Planar reflection:        256
```

Mirror resolution was intentionally left at 512 for image quality.

Vehicle body reflections were already low-resolution, so further reduction was not considered worthwhile.

### Shadow budget reduction

Reducing the native shadow scheduler budget from roughly 3 ms to 1 ms produced little improvement because the expensive view-dependent PSSM path is processed separately from later budget-controlled shadow maps.

### `lastSplitCastersEnabled`

The native runtime value was already disabled (`0`), so there was nothing useful to optimize there.

### Coarse whole-shadow frame skipping

Early versions skipped the whole ShadowMapPass.

That gave large FPS improvements but caused:

- black/flashing world shadows,
- stale near-cascade coverage,
- vehicle-shadow judder,
- high-speed/low-render-distance flicker.

The final selective PSSM scheduler was developed specifically to avoid those problems.

---

# How the selective shadow scheduler works

BeamOpt's final shadow optimization was developed by mapping the BeamNG 0.39.4 PSSM render path.

Relevant recovered behavior includes:

```text
PSSMLightShadowMap::_render
    world PSSM cascade work
    world shadow atlas operations
    world render-state cleanup
    dedicated VehicleShadowTex path
```

The production scheduler keeps the dedicated vehicle-shadow path full-rate while pairing the expensive world atlas clear and world cascade rendering on the same update phase.

This is why it can reduce world-shadow work without simply making every shadow—including the vehicle shadow—update at the reduced rate.

---

# Safety / native-hook status

BeamOpt is a reverse-engineered performance mod.

It:

- opens the BeamNG process,
- reads native object state,
- allocates small executable trampoline pages,
- patches selected native instructions in RAM,
- restores the original bytes when disabled or closed normally.

It does **not** permanently modify `BeamNG.drive.x64.exe` on disk.

Use it at your own risk and keep normal backups of your BeamNG user folder/mod configuration.

---


## 3.9.1

- Fixed automatic mirror profile switching.
- Uses BeamNG `core_camera` camera-mode changes instead of `0 mirrors = exterior`.
- Driver/cockpit mode reapplies the saved interior mirror divisor automatically.
- Exterior cameras disable only the effective mirror throttle; the saved interior preference is preserved.
- Camera changes trigger one immediate bridge-control update; normal LOW-I/O polling remains 0.5 Hz.
- Runtime pattern scanning and all 3.9.0 shadow/PSSM optimizations are unchanged.


## 3.9.2

- Fixed reflector discovery on the tested BeamNG build.
- BeamNG's live manager RTTI is `.?AVReflectionManager@engine@@`; 3.9.1 mistakenly validated only `ReflectorManager`.
- The shared topology scan now accepts `ReflectionManager`, restoring mirror, vehicle-body reflection, and planar-reflection discovery.
- Automatic mirror camera switching from 3.9.1 is unchanged.
- Runtime pattern scanning and selective PSSM optimizations are unchanged.

# Current release

```text
BeamOpt v3.9.2
Primary tested build: BeamNG.drive 0.39.4.0.20972 Win64
Compatibility: runtime pattern scan; later versions attempted when native structures/signatures still match
```

Current recommended baseline:

```text
DX11
World Shadows 1/2
PSSM 6.0 ON
World Caster Mask 0x100 ON
4 PSSM splits
Auto interior/exterior mirror profile ON
Interior mirrors 1/2
```

On the development system, this configuration increased interior DX11 performance from approximately **24.5 FPS to 36 FPS**, while the complete optimization stack produced substantial gains in multiple test scenes.

Results will vary by system.
