﻿<#
.SYNOPSIS
  BeamOpt v3.9.2 combined native bridge. Pattern-scan native bridge. Baseline signatures recovered on BeamNG.drive 0.39.4.0.20972.

.DESCRIPTION
  BeamNG mod Lua is sandboxed and cannot load kernel32 through LuaJIT FFI.
  This companion process owns the verified live-memory optimizations while the
  in-game BeamOpt extension controls them through JSON files in the active
  BeamNG user-folder settings directory.

  v3.8.0 keeps the v3.7.2 LOW-I/O + phase-staggered reflector path and adds:
    - selective world-PSSM scheduling at Native / 1/2 / 1/3 / 1/4 / 1/5;
    - the dedicated VehicleShadowTex path remains full-rate;
    - the world-atlas clear and world-cascade render are synchronized so
      skipped world-shadow frames retain the previous valid atlas;
    - optional PSSM 6.0 writer-freeze optimization;
    - optional world caster mask 0x100 optimization;
    - optional 3-split PSSM optimization.

  BeamNG.drive.x64.exe on disk is never modified. All changes are RAM-only.

  Press Q to restore ALL owned hooks/patches before closing the bridge. If this
  process is forcibly terminated, fully exit BeamNG before starting another
  bridge instance.
#>

[CmdletBinding()]
param(
    [ValidateRange(2, 60)]
    [int]$StaleControlSeconds = 10,

    # Optional exact path to beamopt_native_bridge.json. Normally not needed.
    [string]$ControlPath = '',

    # Optional BeamNG user-folder root to search recursively.
    [string]$UserRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ($env:OS -ne 'Windows_NT') { throw 'BeamOpt Native Bridge must be run on Windows.' }
if ([IntPtr]::Size -ne 8) { throw 'Run the 64-bit Windows PowerShell host.' }

$TestedExeSize = [Int64]46154872  # informational baseline only

# ---------------------------------------------------------------------------
# Runtime pattern signatures
# ---------------------------------------------------------------------------
# BeamOpt 3.9.0 no longer uses the recovered 0.39.4 RVAs as live addresses.
# The active BeamNG executable is scanned at runtime and the target RVAs are
# resolved from native instruction patterns / RIP-relative references.
#
# ?? = wildcard byte.  Patterns intentionally wildcard rel32/RIP displacements
# that commonly change when code is relocated between BeamNG builds.

$ReflectorRegistrationPattern =
    '80 79 30 00 75 1B 48 89 51 48 48 8B D1 C6 41 30 01 4C 89 41 50 48 8B 0D ?? ?? ?? ?? E9 ?? ?? ?? ??'
$FaceCountStorePattern = '89 86 40 03 00 00'
$ExpectedFaceCountStoreHex = '89 86 40 03 00 00'
$MaximumReflectors = 256

$ShadowLoopPattern =
    '41 39 BF B8 01 00 00 0F 86 ?? ?? ?? ??'
$ShadowLoopPatchLength = 13

$ShadowClearContextPattern =
    '49 8B 97 88 01 00 00 FF 90 B0 00 00 00'
$ShadowClearPatchLength = 6

$Pssm6SplitPattern =
    'F3 0F 59 35 ?? ?? ?? ?? F3 0F 5D 35 ?? ?? ?? ?? F3 0F 10 05 ?? ?? ?? ??'
$Pssm6WriterPattern =
    'F3 0F 11 0D ?? ?? ?? ??'
$Pssm6TestValue = [single]6.0

$CasterPattern =
    '41 BE 00 03 00 00 41 8B 87 B8 01 00 00 FF C8 8B 4D 90 3B C8'
$CasterNativeImmediateHex = '00 03 00 00'
$CasterFastImmediateHex = '00 01 00 00'

$SplitComparePattern = '41 83 BF B8 01 00 00 04'
$SplitSetterPattern = 'BA 04 00 00 00'

if ($null -eq ('BeamNGMirrorRateTest039' -as [type])) {
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class BeamNGMirrorRateTest039
{
    [StructLayout(LayoutKind.Sequential)]
    public struct MEMORY_BASIC_INFORMATION
    {
        public IntPtr BaseAddress;
        public IntPtr AllocationBase;
        public UInt32 AllocationProtect;
        public UIntPtr RegionSize;
        public UInt32 State;
        public UInt32 Protect;
        public UInt32 Type;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr OpenProcess(
        uint dwDesiredAccess,
        bool bInheritHandle,
        int dwProcessId);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool ReadProcessMemory(
        IntPtr hProcess,
        IntPtr lpBaseAddress,
        [Out] byte[] lpBuffer,
        UIntPtr nSize,
        out UIntPtr lpNumberOfBytesRead);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool WriteProcessMemory(
        IntPtr hProcess,
        IntPtr lpBaseAddress,
        byte[] lpBuffer,
        UIntPtr nSize,
        out UIntPtr lpNumberOfBytesWritten);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool VirtualProtectEx(
        IntPtr hProcess,
        IntPtr lpAddress,
        UIntPtr dwSize,
        uint flNewProtect,
        out uint lpflOldProtect);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr VirtualAllocEx(
        IntPtr hProcess,
        IntPtr lpAddress,
        UIntPtr dwSize,
        uint flAllocationType,
        uint flProtect);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool VirtualFreeEx(
        IntPtr hProcess,
        IntPtr lpAddress,
        UIntPtr dwSize,
        uint dwFreeType);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool FlushInstructionCache(
        IntPtr hProcess,
        IntPtr lpBaseAddress,
        UIntPtr dwSize);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern UIntPtr VirtualQueryEx(
        IntPtr hProcess,
        IntPtr lpAddress,
        out MEMORY_BASIC_INFORMATION lpBuffer,
        UIntPtr dwLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool CloseHandle(IntPtr hObject);
}
'@
}


if ($null -eq ('BeamOptPatternScanner390' -as [type])) {
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;

public static class BeamOptPatternScanner390
{
    public static int[] FindAll(
        byte[] data,
        int start,
        int count,
        byte[] pattern,
        byte[] mask,
        int maxMatches)
    {
        var hits = new List<int>();
        if (data == null || pattern == null || mask == null) return hits.ToArray();
        if (pattern.Length == 0 || pattern.Length != mask.Length) return hits.ToArray();
        if (start < 0 || count < 0 || start > data.Length) return hits.ToArray();

        int end = Math.Min(data.Length, start + count);
        int last = end - pattern.Length;
        if (last < start) return hits.ToArray();

        int anchor = -1;
        for (int i = 0; i < mask.Length; i++) {
            if (mask[i] != 0) { anchor = i; break; }
        }

        for (int pos = start; pos <= last; pos++) {
            if (anchor >= 0 && data[pos + anchor] != pattern[anchor]) continue;

            bool ok = true;
            for (int j = 0; j < pattern.Length; j++) {
                if (mask[j] != 0 && data[pos + j] != pattern[j]) {
                    ok = false;
                    break;
                }
            }

            if (ok) {
                hits.Add(pos);
                if (maxMatches > 0 && hits.Count >= maxMatches) break;
            }
        }

        return hits.ToArray();
    }
}
'@
}

$script:PeScanCache = @{}

function Convert-ScanPattern {
    param([string]$Pattern)

    [string[]]$tokens = @($Pattern.Trim() -split '\s+')
    [byte[]]$bytes = New-Object byte[] $tokens.Count
    [byte[]]$mask = New-Object byte[] $tokens.Count

    for ($i = 0; $i -lt $tokens.Count; $i++) {
        $t = $tokens[$i]
        if ($t -eq '??' -or $t -eq '?') {
            $bytes[$i] = 0
            $mask[$i] = 0
        }
        else {
            $bytes[$i] = [Convert]::ToByte($t,16)
            $mask[$i] = 1
        }
    }

    return [pscustomobject]@{
        Bytes = $bytes
        Mask = $mask
        Length = $tokens.Count
    }
}

function Get-PeScanContext {
    param([string]$ExePath)

    $file = Get-Item -LiteralPath $ExePath -ErrorAction Stop
    $full = $file.FullName
    $key = "$full|$($file.Length)|$($file.LastWriteTimeUtc.Ticks)"

    if ($script:PeScanCache.ContainsKey($key)) {
        return $script:PeScanCache[$key]
    }

    [byte[]]$bytes = [IO.File]::ReadAllBytes($full)
    if ($bytes.Length -lt 0x100) { throw 'BeamNG executable is too small to parse' }

    [int]$pe = [BitConverter]::ToInt32($bytes,0x3C)
    if ($pe -lt 0 -or $pe + 0x108 -ge $bytes.Length) {
        throw 'invalid PE header offset'
    }

    if ($bytes[$pe] -ne 0x50 -or $bytes[$pe+1] -ne 0x45) {
        throw 'BeamNG executable does not contain a PE signature'
    }

    [int]$fileHeader = $pe + 4
    [int]$sectionCount = [BitConverter]::ToUInt16($bytes,$fileHeader + 2)
    [int]$optSize = [BitConverter]::ToUInt16($bytes,$fileHeader + 16)
    [int]$opt = $fileHeader + 20

    [UInt16]$magic = [BitConverter]::ToUInt16($bytes,$opt)
    if ($magic -ne 0x20B) { throw 'BeamNG executable is not PE32+ x64' }

    [UInt64]$preferredImageBase = [BitConverter]::ToUInt64($bytes,$opt + 24)
    [UInt32]$sizeOfImage = [BitConverter]::ToUInt32($bytes,$opt + 56)

    [int]$table = $opt + $optSize
    $sections = @()

    for ($i = 0; $i -lt $sectionCount; $i++) {
        [int]$o = $table + ($i * 40)
        if ($o + 39 -ge $bytes.Length) { throw 'PE section table is truncated' }

        [byte[]]$nameBytes = $bytes[$o..($o+7)]
        $name = [Text.Encoding]::ASCII.GetString($nameBytes).Trim([char]0)

        $sections += [pscustomobject]@{
            Name = $name
            VirtualSize = [UInt64][BitConverter]::ToUInt32($bytes,$o+8)
            Rva = [UInt64][BitConverter]::ToUInt32($bytes,$o+12)
            RawSize = [UInt64][BitConverter]::ToUInt32($bytes,$o+16)
            Raw = [UInt64][BitConverter]::ToUInt32($bytes,$o+20)
        }
    }

    $ctx = [pscustomobject]@{
        Path = $full
        Length = [Int64]$file.Length
        Bytes = $bytes
        Sections = $sections
        PreferredImageBase = $preferredImageBase
        SizeOfImage = [UInt64]$sizeOfImage
        Resolved = @{}
    }

    $script:PeScanCache[$key] = $ctx
    Write-Host ("[BeamOpt] loaded PE scan image: {0} ({1:N0} bytes)" -f $file.Name,$file.Length)
    return $ctx
}

function Get-PeSectionForRva {
    param($Context,[UInt64]$Rva)

    foreach ($s in @($Context.Sections)) {
        [UInt64]$span = [Math]::Max([UInt64]$s.VirtualSize,[UInt64]$s.RawSize)
        if ($Rva -ge [UInt64]$s.Rva -and $Rva -lt ([UInt64]$s.Rva + $span)) {
            return $s
        }
    }
    return $null
}

function Convert-PeRvaToRaw {
    param($Context,[UInt64]$Rva)

    $s = Get-PeSectionForRva -Context $Context -Rva $Rva
    if ($null -eq $s) { return $null }

    [UInt64]$delta = $Rva - [UInt64]$s.Rva
    if ($delta -ge [UInt64]$s.RawSize) { return $null }

    return [UInt64]$s.Raw + $delta
}

function Read-PeBytesAtRva {
    param($Context,[UInt64]$Rva,[int]$Count)

    $rawObj = Convert-PeRvaToRaw -Context $Context -Rva $Rva
    if ($null -eq $rawObj) { throw ("RVA 0x{0:X} is not backed by file data" -f $Rva) }

    [int]$raw = [int][UInt64]$rawObj
    if ($Count -lt 0 -or $raw + $Count -gt $Context.Bytes.Length) {
        throw ("PE read outside file at RVA 0x{0:X}" -f $Rva)
    }

    [byte[]]$out = New-Object byte[] $Count
    [Array]::Copy($Context.Bytes,$raw,$out,0,$Count)
    return ,$out
}

function Find-PatternRvas {
    param(
        $Context,
        [string]$Pattern,
        [string[]]$Sections = @('.text'),
        [int]$MaxMatches = 64
    )

    $spec = Convert-ScanPattern $Pattern
    $result = New-Object System.Collections.Generic.List[UInt64]

    foreach ($sectionName in $Sections) {
        $matches = @($Context.Sections | Where-Object { $_.Name -eq $sectionName })
        foreach ($s in $matches) {
            if ([UInt64]$s.RawSize -eq 0) { continue }

            [int[]]$rawHits = [BeamOptPatternScanner390]::FindAll(
                $Context.Bytes,
                [int][UInt64]$s.Raw,
                [int][UInt64]$s.RawSize,
                $spec.Bytes,
                $spec.Mask,
                $MaxMatches)

            foreach ($raw in $rawHits) {
                [UInt64]$rva = [UInt64]$s.Rva + ([UInt64]$raw - [UInt64]$s.Raw)
                $result.Add($rva)
                if ($MaxMatches -gt 0 -and $result.Count -ge $MaxMatches) {
                    return @($result.ToArray())
                }
            }
        }
    }

    return @($result.ToArray())
}

function Resolve-UniquePatternRva {
    param(
        $Context,
        [string]$Name,
        [string]$Pattern,
        [string[]]$Sections = @('.text')
    )

    [UInt64[]]$hits = @(Find-PatternRvas -Context $Context -Pattern $Pattern -Sections $Sections -MaxMatches 8)
    if ($hits.Count -eq 0) {
        throw "$Name pattern was not found"
    }
    if ($hits.Count -ne 1) {
        throw "$Name pattern is ambiguous ($($hits.Count) matches)"
    }

    return [UInt64]$hits[0]
}

function Get-Rel32TargetRva {
    param(
        $Context,
        [UInt64]$InstructionRva,
        [int]$DispOffset,
        [int]$InstructionLength
    )

    [byte[]]$b = Read-PeBytesAtRva -Context $Context -Rva $InstructionRva -Count $InstructionLength
    [Int32]$disp = [BitConverter]::ToInt32($b,$DispOffset)
    [Int64]$target = [Int64]$InstructionRva + [Int64]$InstructionLength + [Int64]$disp
    if ($target -lt 0 -or $target -ge [Int64]$Context.SizeOfImage) {
        throw ("rel32/RIP target from RVA 0x{0:X} is outside the module image" -f $InstructionRva)
    }
    return [UInt64]$target
}

function Test-ModuleTextAddress {
    param(
        $Context,
        [UInt64]$ModuleBase,
        [UInt64]$Address
    )

    if ($Address -lt $ModuleBase) { return $false }
    [UInt64]$rva = $Address - $ModuleBase
    $s = Get-PeSectionForRva -Context $Context -Rva $rva
    return ($null -ne $s -and $s.Name -eq '.text')
}

function Get-LiveRttiTypeName {
    param(
        [IntPtr]$Handle,
        [UInt64]$ModuleBase,
        $Context,
        [UInt64]$VtableAddress
    )

    try {
        if ($VtableAddress -lt ($ModuleBase + 8)) { return '' }

        [UInt64]$col = Read-RemoteUInt64 -Handle $Handle -Address ($VtableAddress - 8)
        if ($col -lt $ModuleBase -or $col -ge ($ModuleBase + [UInt64]$Context.SizeOfImage)) {
            return ''
        }

        [byte[]]$colBytes = Read-RemoteBytes -Handle $Handle -Address $col -Count 24
        [UInt32]$signature = [BitConverter]::ToUInt32($colBytes,0)
        if ($signature -ne 1) { return '' }

        [UInt32]$typeRva = [BitConverter]::ToUInt32($colBytes,12)
        if ($typeRva -eq 0 -or [UInt64]$typeRva -ge [UInt64]$Context.SizeOfImage) {
            return ''
        }

        [byte[]]$nameBytes = Read-RemoteBytes `
            -Handle $Handle `
            -Address ($ModuleBase + [UInt64]$typeRva + 16) `
            -Count 160

        $chars = New-Object System.Collections.Generic.List[char]
        foreach ($v in $nameBytes) {
            if ($v -eq 0) { break }
            if ($v -lt 0x20 -or $v -gt 0x7E) { return '' }
            $chars.Add([char]$v)
        }

        return (-join $chars.ToArray())
    }
    catch {
        return ''
    }
}

function Resolve-ReflectorScanLayout {
    param($Context)

    if ($Context.Resolved.ContainsKey('reflector')) {
        return $Context.Resolved['reflector']
    }

    [UInt64]$registration = Resolve-UniquePatternRva `
        -Context $Context `
        -Name 'Reflector registration helper' `
        -Pattern $ReflectorRegistrationPattern `
        -Sections @('.text')

    # Registration pattern contains:
    #   +0x15: 48 8B 0D disp32
    # The RIP target is the ReflectorManager singleton pointer.
    [UInt64]$globalManager = Get-Rel32TargetRva `
        -Context $Context `
        -InstructionRva ($registration + 0x15) `
        -DispOffset 3 `
        -InstructionLength 7

    [UInt64]$faceStore = 0
    [UInt64[]]$faceHits = @(Find-PatternRvas `
        -Context $Context `
        -Pattern $FaceCountStorePattern `
        -Sections @('.text') `
        -MaxMatches 32)

    if ($faceHits.Count -gt 0) {
        $near = @($faceHits | Where-Object {
            [Math]::Abs([Int64]$_ - [Int64]$registration) -lt 0x20000
        } | Sort-Object { [Math]::Abs([Int64]$_ - [Int64]$registration) })

        if ($near.Count -gt 0) { $faceStore = [UInt64]$near[0] }
    }

    $layout = [pscustomobject]@{
        RegistrationRva = $registration
        GlobalManagerRva = $globalManager
        FaceCountStoreRva = $faceStore
    }

    $Context.Resolved['reflector'] = $layout
    Write-Host ("[BeamOpt] pattern scan ReflectionManager: global RVA 0x{0:X}" -f $globalManager)
    return $layout
}

function Resolve-ShadowScanLayout {
    param($Context)

    if ($Context.Resolved.ContainsKey('shadow')) {
        return $Context.Resolved['shadow']
    }

    [UInt64]$loop = Resolve-UniquePatternRva `
        -Context $Context -Name 'PSSM world-loop gate' `
        -Pattern $ShadowLoopPattern -Sections @('.text')

    [UInt64]$clearContext = Resolve-UniquePatternRva `
        -Context $Context -Name 'PSSM atlas-clear context' `
        -Pattern $ShadowClearContextPattern -Sections @('.text')

    [UInt64]$continue = $loop + [UInt64]$ShadowLoopPatchLength
    [UInt64]$skip = Get-Rel32TargetRva `
        -Context $Context `
        -InstructionRva ($loop + 7) `
        -DispOffset 2 `
        -InstructionLength 6

    [UInt64]$clearCall = $clearContext + 7
    [UInt64]$clearContinue = $clearContext + 13

    if ($clearContext -ge $loop -or ($loop - $clearContext) -gt 0x3000) {
        throw 'PSSM clear/loop patterns did not resolve into the expected function neighborhood'
    }
    if ($skip -le $loop -or ($skip - $loop) -gt 0x5000) {
        throw 'PSSM world-loop skip target failed structural validation'
    }

    [byte[]]$nativeLoop = Read-PeBytesAtRva -Context $Context -Rva $loop -Count $ShadowLoopPatchLength
    [byte[]]$nativeClear = Read-PeBytesAtRva -Context $Context -Rva $clearCall -Count $ShadowClearPatchLength

    $layout = [pscustomobject]@{
        LoopRva = $loop
        ContinueRva = $continue
        SkipRva = $skip
        ClearContextRva = $clearContext
        ClearCallRva = $clearCall
        ClearContinueRva = $clearContinue
        NativeLoop = $nativeLoop
        NativeClear = $nativeClear
    }

    $Context.Resolved['shadow'] = $layout
    Write-Host ("[BeamOpt] pattern scan shadow: loop RVA 0x{0:X}, clear RVA 0x{1:X}" -f $loop,$clearCall)
    return $layout
}

function Resolve-Pssm6ScanLayout {
    param($Context)

    if ($Context.Resolved.ContainsKey('pssm6')) {
        return $Context.Resolved['pssm6']
    }

    [UInt64]$split = Resolve-UniquePatternRva `
        -Context $Context -Name 'PSSM split-distribution math' `
        -Pattern $Pssm6SplitPattern -Sections @('.text')

    # Second 8-byte instruction is:
    #   F3 0F 5D 35 disp32
    [UInt64]$valueRva = Get-Rel32TargetRva `
        -Context $Context `
        -InstructionRva ($split + 8) `
        -DispOffset 4 `
        -InstructionLength 8

    [UInt64[]]$writers = @(Find-PatternRvas `
        -Context $Context `
        -Pattern $Pssm6WriterPattern `
        -Sections @('.text') `
        -MaxMatches 128)

    $matching = New-Object System.Collections.Generic.List[UInt64]
    foreach ($candidate in $writers) {
        try {
            [UInt64]$target = Get-Rel32TargetRva `
                -Context $Context `
                -InstructionRva ([UInt64]$candidate) `
                -DispOffset 4 `
                -InstructionLength 8

            if ($target -eq $valueRva) { $matching.Add([UInt64]$candidate) }
        }
        catch { }
    }

    if ($matching.Count -ne 1) {
        throw "PSSM 6.0 writer resolution expected 1 match, found $($matching.Count)"
    }

    [UInt64]$writer = [UInt64]$matching[0]
    [byte[]]$nativeWriter = Read-PeBytesAtRva -Context $Context -Rva $writer -Count 8
    [byte[]]$nativeSplit = Read-PeBytesAtRva -Context $Context -Rva $split -Count 24

    $layout = [pscustomobject]@{
        SplitRva = $split
        ValueRva = $valueRva
        WriterRva = $writer
        NativeWriter = $nativeWriter
        NativeSplit = $nativeSplit
    }

    $Context.Resolved['pssm6'] = $layout
    Write-Host ("[BeamOpt] pattern scan PSSM 6.0: writer RVA 0x{0:X}, value RVA 0x{1:X}" -f $writer,$valueRva)
    return $layout
}

function Resolve-CasterScanLayout {
    param($Context)

    if ($Context.Resolved.ContainsKey('caster')) {
        return $Context.Resolved['caster']
    }

    [UInt64]$inst = Resolve-UniquePatternRva `
        -Context $Context -Name 'world caster mask' `
        -Pattern $CasterPattern -Sections @('.text')

    $layout = [pscustomobject]@{
        InstructionRva = $inst
        ImmediateRva = $inst + 2
        NativeContext = Read-PeBytesAtRva -Context $Context -Rva $inst -Count 20
    }

    $Context.Resolved['caster'] = $layout
    Write-Host ("[BeamOpt] pattern scan caster mask: RVA 0x{0:X}" -f $inst)
    return $layout
}

function Resolve-Split3ScanLayout {
    param($Context)

    if ($Context.Resolved.ContainsKey('split3')) {
        return $Context.Resolved['split3']
    }

    [UInt64]$compare = Resolve-UniquePatternRva `
        -Context $Context -Name 'PSSM split-count compare' `
        -Pattern $SplitComparePattern -Sections @('.text')

    [UInt64[]]$setterHits = @(Find-PatternRvas `
        -Context $Context `
        -Pattern $SplitSetterPattern `
        -Sections @('.text') `
        -MaxMatches 256)

    $near = @($setterHits | Where-Object {
        [UInt64]$_ -gt $compare -and [UInt64]$_ -lt ($compare + 0x50)
    })

    if ($near.Count -ne 1) {
        throw "PSSM split-count setter resolution expected 1 nearby match, found $($near.Count)"
    }

    [UInt64]$setter = [UInt64]$near[0]

    $layout = [pscustomobject]@{
        CompareInstructionRva = $compare
        CompareImmediateRva = $compare + 7
        SetterInstructionRva = $setter
        SetterImmediateRva = $setter + 1
        NativeCompare = Read-PeBytesAtRva -Context $Context -Rva $compare -Count 8
        NativeSetter = Read-PeBytesAtRva -Context $Context -Rva $setter -Count 5
    }

    $Context.Resolved['split3'] = $layout
    Write-Host ("[BeamOpt] pattern scan split-count: compare RVA 0x{0:X}, setter RVA 0x{1:X}" -f $compare,$setter)
    return $layout
}


function Format-HexAddress {
    param([UInt64]$Value)
    return ('0x{0:X}' -f $Value)
}

function Convert-HexStringToBytes {
    param([string]$Hex)
    [byte[]]$bytes = @(($Hex.Trim() -split '\s+') | ForEach-Object {
        [Convert]::ToByte($_, 16)
    })
    return ,$bytes
}

function Convert-BytesToHex {
    param([byte[]]$Bytes)
    return (($Bytes | ForEach-Object { $_.ToString('X2') }) -join ' ')
}

function Test-ByteArraysEqual {
    param([byte[]]$Left, [byte[]]$Right)
    if ($Left.Length -ne $Right.Length) { return $false }
    for ($i = 0; $i -lt $Left.Length; $i++) {
        if ($Left[$i] -ne $Right[$i]) { return $false }
    }
    return $true
}

function Read-RemoteBytes {
    param([IntPtr]$Handle, [UInt64]$Address, [int]$Count)

    [byte[]]$buffer = New-Object byte[] $Count
    [UIntPtr]$bytesRead = [UIntPtr]::Zero
    $ok = [BeamNGMirrorRateTest039]::ReadProcessMemory(
        $Handle,
        [IntPtr]([Int64]$Address),
        $buffer,
        [UIntPtr]([UInt64]$Count),
        [ref]$bytesRead)
    $actual = [Int64]$bytesRead.ToUInt64()

    if (-not $ok -or $actual -ne $Count) {
        $win32 = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "ReadProcessMemory failed at $(Format-HexAddress $Address): requested $Count, got $actual, Win32=$win32"
    }
    return ,$buffer
}

function Read-RemoteUInt64 {
    param([IntPtr]$Handle, [UInt64]$Address)
    [byte[]]$bytes = Read-RemoteBytes -Handle $Handle -Address $Address -Count 8
    return [BitConverter]::ToUInt64($bytes, 0)
}

function Read-RemoteUInt32 {
    param([IntPtr]$Handle, [UInt64]$Address)
    [byte[]]$bytes = Read-RemoteBytes -Handle $Handle -Address $Address -Count 4
    return [BitConverter]::ToUInt32($bytes, 0)
}

function Write-RemoteBytes {
    param([IntPtr]$Handle, [UInt64]$Address, [byte[]]$Data)

    [UIntPtr]$bytesWritten = [UIntPtr]::Zero
    $ok = [BeamNGMirrorRateTest039]::WriteProcessMemory(
        $Handle,
        [IntPtr]([Int64]$Address),
        $Data,
        [UIntPtr]([UInt64]$Data.Length),
        [ref]$bytesWritten)
    if (-not $ok -or $bytesWritten.ToUInt64() -ne [UInt64]$Data.Length) {
        $win32 = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "WriteProcessMemory failed at $(Format-HexAddress $Address), Win32=$win32"
    }
}

function Write-ProtectedRemoteBytes {
    param([IntPtr]$Handle, [UInt64]$Address, [byte[]]$Data)

    $PAGE_EXECUTE_READWRITE = [UInt32]0x40
    [UInt32]$oldProtect = 0
    [UInt32]$ignoredProtect = 0
    $protectionChanged = $false

    $protectOk = [BeamNGMirrorRateTest039]::VirtualProtectEx(
        $Handle,
        [IntPtr]([Int64]$Address),
        [UIntPtr]([UInt64]$Data.Length),
        $PAGE_EXECUTE_READWRITE,
        [ref]$oldProtect)
    if (-not $protectOk) {
        $win32 = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "VirtualProtectEx failed at $(Format-HexAddress $Address), Win32=$win32"
    }
    $protectionChanged = $true

    try {
        Write-RemoteBytes -Handle $Handle -Address $Address -Data $Data
    }
    finally {
        if ($protectionChanged) {
            $restoreOk = [BeamNGMirrorRateTest039]::VirtualProtectEx(
                $Handle,
                [IntPtr]([Int64]$Address),
                [UIntPtr]([UInt64]$Data.Length),
                $oldProtect,
                [ref]$ignoredProtect)
            if (-not $restoreOk) {
                Write-Warning "Could not restore page protection at $(Format-HexAddress $Address)."
            }
        }
    }
}

function Get-BeamNGSelection {
    param([int]$RequestedProcessId)

    if ($RequestedProcessId -ne 0) {
        $candidates = @(Get-Process -Id $RequestedProcessId -ErrorAction Stop)
    }
    else {
        $candidates = @(Get-Process -ErrorAction Stop | Where-Object {
            $_.ProcessName -like 'BeamNG.drive*'
        })
    }

    $resolved = @()
    foreach ($candidate in $candidates) {
        try {
            $mainModule = $candidate.MainModule
            if ($null -ne $mainModule -and $mainModule.ModuleName -ieq 'BeamNG.drive.x64.exe') {
                $resolved += [pscustomobject]@{
                    Process = $candidate
                    MainModule = $mainModule
                    WorkingSet = [Int64]$candidate.WorkingSet64
                }
            }
        }
        catch {
            Write-Warning "Could not inspect PID $($candidate.Id)."
        }
    }

    if ($resolved.Count -eq 0) { throw 'BeamNG.drive.x64.exe was not found.' }
    if ($RequestedProcessId -ne 0) { return $resolved[0] }
    return (@($resolved | Sort-Object WorkingSet -Descending))[0]
}

function Add-CodeBytes {
    param(
        [System.Collections.Generic.List[byte]]$Code,
        [byte[]]$Bytes
    )
    foreach ($value in $Bytes) { $Code.Add($value) }
}

function Add-CodeUInt64 {
    param(
        [System.Collections.Generic.List[byte]]$Code,
        [UInt64]$Value
    )
    Add-CodeBytes -Code $Code -Bytes ([BitConverter]::GetBytes($Value))
}

function Set-RelativeInt32 {
    param(
        [byte[]]$Code,
        [int]$DisplacementOffset,
        [int]$TargetOffset
    )
    [Int32]$relative = [Int32]($TargetOffset - ($DisplacementOffset + 4))
    [byte[]]$encoded = [BitConverter]::GetBytes($relative)
    [Array]::Copy($encoded, 0, $Code, $DisplacementOffset, 4)
}

function New-ObjectRateDispatcher {
    param(
        [UInt64[]]$TargetObjects,
        [int[]]$TargetDivisors,
        [UInt64]$OriginalTarget,
        [UInt64]$RemoteBase
    )

    $count = @($TargetObjects).Count
    if ($count -lt 1 -or $count -gt 96) {
        throw "dispatcher target count outside safety range: $count"
    }
    if (@($TargetDivisors).Count -ne $count) {
        throw 'dispatcher target/divisor array length mismatch'
    }

    $code = New-Object System.Collections.Generic.List[byte]
    $compareDisplacements = New-Object System.Collections.Generic.List[int]
    $handlerOffsets = New-Object System.Collections.Generic.List[int]
    $skipDisplacements = New-Object System.Collections.Generic.List[int]
    $renderDisplacements = New-Object System.Collections.Generic.List[int]

    for ($i = 0; $i -lt $count; $i++) {
        $div = [int]$TargetDivisors[$i]
        if ($div -lt 2 -or $div -gt 8) {
            throw "dispatcher divisor outside range 2..8 at target $i"
        }

        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xB8))
        Add-CodeUInt64 -Code $code -Value ([UInt64]$TargetObjects[$i])
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0x39,0xC1,0x0F,0x84))
        $compareDisplacements.Add($code.Count)
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0,0,0,0))
    }

    # Objects not explicitly selected remain fully native.
    Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xB8))
    Add-CodeUInt64 -Code $code -Value $OriginalTarget
    Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xFF,0xE0))

    [UInt64]$counterBase = $RemoteBase + [UInt64]0x4000

    for ($i = 0; $i -lt $count; $i++) {
        $div = [int]$TargetDivisors[$i]
        $handlerOffsets.Add($code.Count)
        [UInt64]$counterAddress = $counterBase + [UInt64]($i * 4)

        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBA))
        Add-CodeUInt64 -Code $code -Value $counterAddress
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xF0,0x41,0xFF,0x02)) # lock inc [r10]
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0x8B,0x02))      # mov eax,[r10]
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x83,0xF8,[byte]$div))
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x0F,0x82))
        $skipDisplacements.Add($code.Count)
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0,0,0,0))

        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xF0,0x41,0x83,0x22,0x00))
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xE9))
        $renderDisplacements.Add($code.Count)
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0,0,0,0))

        [int]$skipOffset = $code.Count
        Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xC3))

        [byte[]]$tmp = $code.ToArray()
        Set-RelativeInt32 -Code $tmp `
            -DisplacementOffset $skipDisplacements[$i] `
            -TargetOffset $skipOffset
        $code.Clear()
        Add-CodeBytes -Code $code -Bytes $tmp
    }

    [int]$renderOffset = $code.Count
    Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xB8))
    Add-CodeUInt64 -Code $code -Value $OriginalTarget
    Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xFF,0xE0))

    [byte[]]$result = $code.ToArray()
    for ($i = 0; $i -lt $count; $i++) {
        Set-RelativeInt32 -Code $result `
            -DisplacementOffset $compareDisplacements[$i] `
            -TargetOffset $handlerOffsets[$i]
        Set-RelativeInt32 -Code $result `
            -DisplacementOffset $renderDisplacements[$i] `
            -TargetOffset $renderOffset
    }

    if ($result.Length -ge 0x3E00) {
        throw "generated dispatcher unexpectedly large: $($result.Length) bytes"
    }
    return ,$result
}

function Initialize-DispatcherCounters {
    param(
        [IntPtr]$Handle,
        [UInt64]$RemoteBase,
        [int[]]$Divisors
    )

    $count = @($Divisors).Count
    [byte[]]$buffer = New-Object byte[] ($count * 4)

    # Phase-stagger target updates instead of making every object due on the
    # same frame. Example at divisor 2:
    #   target 0 starts at counter 1 -> renders on first intercepted call
    #   target 1 starts at counter 0 -> renders on second intercepted call
    #   target 2 repeats phase 0, target 3 repeats phase 1, etc.
    #
    # This keeps average update frequency unchanged while spreading secondary
    # scene-render work across frames to reduce spikes / improve 1% lows.
    for ($i = 0; $i -lt $count; $i++) {
        $div = [int]$Divisors[$i]
        if ($div -lt 2) { $div = 2 }

        [int]$phase = $i % $div
        [int]$initial = ($div - 1) - $phase
        if ($initial -lt 0) { $initial += $div }

        [byte[]]$counterBytes = [BitConverter]::GetBytes([Int32]$initial)
        [Array]::Copy($counterBytes, 0, $buffer, $i * 4, 4)
    }

    Write-RemoteBytes -Handle $Handle -Address ($RemoteBase + 0x4000) -Data $buffer
}

function Add-ReportLine {
    param([System.Collections.Generic.List[string]]$Report, [string]$Text = '')
    $Report.Add($Text)
    Write-Host $Text
}


function Get-ReflectorTopology {
    param(
        [IntPtr]$Handle,
        [UInt64]$ModuleBase,
        [string]$ExePath
    )

    $context = Get-PeScanContext -ExePath $ExePath
    $layout = Resolve-ReflectorScanLayout -Context $context

    [UInt64]$manager = Read-RemoteUInt64 `
        -Handle $Handle `
        -Address ($ModuleBase + [UInt64]$layout.GlobalManagerRva)

    if ($manager -eq 0) { throw 'reflector manager not ready' }

    [UInt64]$managerVtable = Read-RemoteUInt64 -Handle $Handle -Address $manager
    [string]$managerType = Get-LiveRttiTypeName `
        -Handle $Handle -ModuleBase $ModuleBase -Context $context -VtableAddress $managerVtable

    if (-not [string]::IsNullOrWhiteSpace($managerType) -and
        $managerType -notmatch '(?:ReflectionManager|ReflectorManager)') {
        throw "reflection manager RTTI mismatch: $managerType"
    }

    [byte[]]$managerBytes = Read-RemoteBytes -Handle $Handle -Address $manager -Count 0x28
    [UInt64]$vectorBegin = [BitConverter]::ToUInt64($managerBytes,0x10)
    [UInt64]$vectorEnd = [BitConverter]::ToUInt64($managerBytes,0x18)
    [UInt64]$vectorCapacity = [BitConverter]::ToUInt64($managerBytes,0x20)

    if ($vectorEnd -lt $vectorBegin -or
        $vectorCapacity -lt $vectorEnd -or
        (($vectorEnd - $vectorBegin) % 8) -ne 0) {
        throw 'reflector vector failed structural validation'
    }

    [Int64]$reflectorCount = [Int64](($vectorEnd - $vectorBegin) / 8)
    if ($reflectorCount -lt 1 -or $reflectorCount -gt $MaximumReflectors) {
        throw "reflector count outside safety range: $reflectorCount"
    }

    [byte[]]$pointerBytes = Read-RemoteBytes `
        -Handle $Handle `
        -Address $vectorBegin `
        -Count ([int]$reflectorCount * 8)

    $cubeRecords = @()
    [UInt64[]]$planes = @()
    [UInt64]$cubeVtable = 0
    [UInt64]$planeVtable = 0

    for ($i = 0; $i -lt $reflectorCount; $i++) {
        [UInt64]$objectAddress = [BitConverter]::ToUInt64($pointerBytes,$i*8)
        if ($objectAddress -eq 0) { continue }

        [byte[]]$objectBytes = Read-RemoteBytes -Handle $Handle -Address $objectAddress -Count 0x58
        [UInt64]$objectVtable = [BitConverter]::ToUInt64($objectBytes,0)
        [string]$typeName = Get-LiveRttiTypeName `
            -Handle $Handle -ModuleBase $ModuleBase -Context $context -VtableAddress $objectVtable

        if ($typeName -match 'CubeReflector') {
            if ($cubeVtable -eq 0) { $cubeVtable = $objectVtable }
            elseif ($cubeVtable -ne $objectVtable) {
                throw 'multiple CubeReflector vtables were observed'
            }

            [UInt32]$selectedCount = 0
            try {
                $selectedCount = Read-RemoteUInt32 -Handle $Handle -Address ($objectAddress + 0x340)
            }
            catch { }

            $cubeRecords += [pscustomobject]@{
                Address = $objectAddress
                ContextA = [BitConverter]::ToUInt64($objectBytes,0x48)
                ContextB = [BitConverter]::ToUInt64($objectBytes,0x50)
                SelectedCount = $selectedCount
            }
        }
        elseif ($typeName -match 'PlaneReflector') {
            if ($planeVtable -eq 0) { $planeVtable = $objectVtable }
            elseif ($planeVtable -ne $objectVtable) {
                throw 'multiple PlaneReflector vtables were observed'
            }

            $planes += [UInt64]$objectAddress
        }
    }

    if ($cubeRecords.Count -lt 1) {
        throw 'no RTTI-validated CubeReflectors are currently registered'
    }

    $families = @()
    foreach ($g in @($cubeRecords | Group-Object ContextA)) {
        $members = @($g.Group)
        $descriptorCount = @($members | Select-Object -ExpandProperty ContextB -Unique).Count

        $families += [pscustomobject]@{
            ContextA = [UInt64]$g.Name
            Count = $members.Count
            DescriptorCount = $descriptorCount
            Members = $members
        }
    }

    $vehicleCandidates = @($families | Where-Object {
        $_.Count -ge 2 -and $_.DescriptorCount -ge 2
    } | Sort-Object Count -Descending)

    if ($vehicleCandidates.Count -eq 0) {
        $vehicleCandidates = @($families | Sort-Object Count -Descending)
    }
    if ($vehicleCandidates.Count -eq 0) {
        throw 'could not identify a vehicle CubeReflector family'
    }

    $vehicle = $vehicleCandidates[0]
    $vehicleCubes = @($vehicle.Members)
    $descriptorGroups = @($vehicleCubes | Group-Object ContextB | Sort-Object Count -Descending)

    if ($descriptorGroups.Count -eq 0) {
        throw 'vehicle CubeReflector family has no descriptor groups'
    }

    $mirrorRecords = @()
    if ($descriptorGroups[0].Count -gt 1) {
        $mirrorRecords = @($descriptorGroups[0].Group)
    }
    else {
        $ordered = @($vehicleCubes | Sort-Object SelectedCount -Descending)
        $mirrorRecords = @($ordered[0])
    }

    [UInt64[]]$mirrors = @($mirrorRecords |
        ForEach-Object { [UInt64]$_.Address } |
        Sort-Object)

    [UInt64[]]$dynamic = @($vehicleCubes |
        Where-Object { $mirrors -notcontains [UInt64]$_.Address } |
        ForEach-Object { [UInt64]$_.Address } |
        Sort-Object)

    return [pscustomobject]@{
        Manager = $manager
        ReflectorCount = $reflectorCount
        CubeCount = $cubeRecords.Count
        VehicleCubeCount = $vehicleCubes.Count
        Mirrors = $mirrors
        Dynamic = $dynamic
        Planes = [UInt64[]]@($planes | Sort-Object)
        VehicleContextA = [UInt64]$vehicle.ContextA
        CubeVtable = $cubeVtable
        PlaneVtable = $planeVtable
        FaceCountStoreRva = [UInt64]$layout.FaceCountStoreRva
        ScanContext = $context
    }
}

function Test-SameUInt64Set {
    param([UInt64[]]$A, [UInt64[]]$B)
    if ($null -eq $A -or $null -eq $B -or $A.Count -ne $B.Count) { return $false }
    for ($i = 0; $i -lt $A.Count; $i++) {
        if ([UInt64]$A[$i] -ne [UInt64]$B[$i]) { return $false }
    }
    return $true
}

function Add-ControlSearchRoot {
    param(
        [System.Collections.Generic.List[string]]$Roots,
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    try {
        $resolved = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
        if (-not [IO.Path]::IsPathRooted($resolved)) { return }
        if (-not (Test-Path -LiteralPath $resolved)) { return }

        foreach ($existing in $Roots) {
            if ([string]::Equals($existing, $resolved, [StringComparison]::OrdinalIgnoreCase)) {
                return
            }
        }
        $Roots.Add($resolved)
    }
    catch { }
}

function Get-BeamNGCommandLineUserRoots {
    $roots = New-Object System.Collections.Generic.List[string]

    try {
        $procs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -ieq 'BeamNG.drive.x64.exe' -or $_.Name -like 'BeamNG.drive*.exe'
        })

        foreach ($p in $procs) {
            $cmd = [string]$p.CommandLine
            if ([string]::IsNullOrWhiteSpace($cmd)) { continue }

            $patterns = @(
                '(?i)(?:--?userpath|/userpath)\s*=\s*"([^"]+)"',
                "(?i)(?:--?userpath|/userpath)\s*=\s*'([^']+)'",
                '(?i)(?:--?userpath|/userpath)\s*=\s*([^\s"]+)',
                '(?i)(?:--?userpath|/userpath)\s+"([^"]+)"',
                "(?i)(?:--?userpath|/userpath)\s+'([^']+)'",
                '(?i)(?:--?userpath|/userpath)\s+([^\s"]+)'
            )

            foreach ($pat in $patterns) {
                $m = [regex]::Match($cmd, $pat)
                if ($m.Success -and $m.Groups.Count -gt 1) {
                    Add-ControlSearchRoot -Roots $roots -Path $m.Groups[1].Value
                }
            }
        }
    }
    catch { }

    return $roots.ToArray()
}

function Resolve-BeamNGUserFolder {
    # BeamNG 0.37+ stores the user-folder configuration here.
    # BeamNG's documented default for current builds is:
    #   %LOCALAPPDATA%\BeamNG\BeamNG.drive\current
    $beamRoot = Join-Path $env:LOCALAPPDATA 'BeamNG'
    $iniPath = Join-Path $beamRoot 'BeamNG.drive.ini'
    $defaultUser = Join-Path $beamRoot 'BeamNG.drive\current'

    if (-not (Test-Path -LiteralPath $iniPath -PathType Leaf)) {
        return $defaultUser
    }

    try {
        $lines = Get-Content -LiteralPath $iniPath -ErrorAction Stop
        $configured = $null

        foreach ($line in $lines) {
            $trimmed = ([string]$line).Trim()
            if ($trimmed.Length -eq 0) { continue }
            if ($trimmed.StartsWith('#') -or $trimmed.StartsWith(';')) { continue }

            $m = [regex]::Match($trimmed, '^(?i:userFolder)\s*=\s*(.*)$')
            if ($m.Success) {
                $configured = $m.Groups[1].Value.Trim().Trim('"').Trim("'")
                break
            }
        }

        if ([string]::IsNullOrWhiteSpace($configured)) {
            return $defaultUser
        }

        $configured = [Environment]::ExpandEnvironmentVariables($configured)

        if ([IO.Path]::IsPathRooted($configured)) {
            return $configured
        }

        # BeamNG documents relative values as relative to the INI directory.
        return [IO.Path]::GetFullPath((Join-Path $beamRoot $configured))
    }
    catch {
        return $defaultUser
    }
}

function Get-ControlSearchRoots {
    $roots = New-Object System.Collections.Generic.List[string]

    if (-not [string]::IsNullOrWhiteSpace($UserRoot)) {
        Add-ControlSearchRoot -Roots $roots -Path $UserRoot
    }

    # First use BeamNG's own documented user-folder configuration.
    $resolvedUser = Resolve-BeamNGUserFolder
    Add-ControlSearchRoot -Roots $roots -Path $resolvedUser

    # A command-line userpath, when present, may override the configured folder.
    foreach ($p in @(Get-BeamNGCommandLineUserRoots)) {
        Add-ControlSearchRoot -Roots $roots -Path $p
    }

    # Keep legacy locations only as fallbacks for migrated/custom installations.
    Add-ControlSearchRoot -Roots $roots -Path (Join-Path $env:LOCALAPPDATA 'BeamNG.drive')

    try {
        $docs = [Environment]::GetFolderPath('MyDocuments')
        if ($docs) {
            Add-ControlSearchRoot -Roots $roots -Path (Join-Path $docs 'BeamNG.drive')
        }
    }
    catch { }

    if ($env:OneDrive) {
        Add-ControlSearchRoot -Roots $roots -Path (Join-Path $env:OneDrive 'Documents\BeamNG.drive')
    }

    return $roots.ToArray()
}

function Use-ControlFile {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $null
    }

    $item = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if ($null -eq $item -or $item.Name -ine 'beamopt_native_bridge.json') {
        return $null
    }

    $script:ControlPath = $item.FullName
    $script:SettingsDir = Split-Path -Parent $script:ControlPath
    $script:StatusPath = Join-Path $script:SettingsDir 'beamopt_native_status.json'

    if (-not $script:ControlPathAnnounced) {
        Write-Host "[BeamOpt Native Bridge] control file: $($script:ControlPath)"
        Write-Host "[BeamOpt Native Bridge] status file:  $($script:StatusPath)"
        $script:ControlPathAnnounced = $true
    }

    return $script:ControlPath
}

function Get-ControlFile {
    if ($script:ControlPath -and (Test-Path -LiteralPath $script:ControlPath -PathType Leaf)) {
        return $script:ControlPath
    }

    if (-not [string]::IsNullOrWhiteSpace($ControlPath)) {
        $manual = $ControlPath
        if (Test-Path -LiteralPath $manual -PathType Container) {
            $manual = Join-Path $manual 'beamopt_native_bridge.json'
        }

        $selected = Use-ControlFile -Path $manual
        if ($selected) { return $selected }
    }

    # Do not recursively rescan the filesystem on every 100 ms bridge tick.
    if ([DateTime]::UtcNow -lt $script:NextControlDiscoveryUtc) {
        return $null
    }
    $script:NextControlDiscoveryUtc = [DateTime]::UtcNow.AddSeconds(2)

    $roots = @(Get-ControlSearchRoots)
    $script:LastSearchRoots = $roots

    $hits = @()
    foreach ($root in $roots) {
        try {
            $hits += @(Get-ChildItem -LiteralPath $root `
                -Filter 'beamopt_native_bridge.json' `
                -File -Recurse -ErrorAction SilentlyContinue)
        }
        catch { }
    }

    if ($hits.Count -gt 0) {
        $freshest = @($hits | Sort-Object LastWriteTimeUtc -Descending)[0]
        return Use-ControlFile -Path $freshest.FullName
    }

    return $null
}

function Read-Control {
    $path = Get-ControlFile
    if (-not $path) { return $null }

    try {
        $item = Get-Item -LiteralPath $path -ErrorAction Stop
        $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
        $data = $raw | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $data) { return $null }

        function Clamp-Divisor([object]$Value, [int]$Default = 2) {
            [int]$d = $Default
            try { if ($null -ne $Value) { $d = [int]$Value } } catch { }
            if ($d -lt 2) { $d = 2 }
            if ($d -gt 8) { $d = 8 }
            return $d
        }

        [int]$mirrorDivisor = Clamp-Divisor $data.mirrorDivisor 2
        [int]$dynamicDivisor = Clamp-Divisor $data.dynamicDivisor 2
        [int]$planeDivisor = Clamp-Divisor $data.planeDivisor 2

        [int]$shadowDivisor = 2
        try { if ($null -ne $data.shadowDivisor) { $shadowDivisor = [int]$data.shadowDivisor } } catch { }
        if ($shadowDivisor -lt 2) { $shadowDivisor = 2 }
        if ($shadowDivisor -gt 5) { $shadowDivisor = 5 }

        $mirrorDesired = ($null -ne $data.mirrorEnabled -and $data.mirrorEnabled -eq $true)
        if ($null -eq $data.mirrorEnabled -and $null -ne $data.desired) {
            $mirrorDesired = ($data.desired -eq $true)
        }

        $mirrorAutoViewEnabled = $true
        if ($null -ne $data.mirrorAutoViewEnabled) {
            $mirrorAutoViewEnabled = ($data.mirrorAutoViewEnabled -eq $true)
        }

        $mirrorPreferenceDesired = $mirrorDesired
        if ($null -ne $data.mirrorPreferenceEnabled) {
            $mirrorPreferenceDesired = ($data.mirrorPreferenceEnabled -eq $true)
        }

        [string]$mirrorCameraName = 'unknown'
        if ($null -ne $data.mirrorCameraName) {
            $mirrorCameraName = [string]$data.mirrorCameraName
        }

        $mirrorCameraInterior = $null
        if ($null -ne $data.mirrorCameraInterior) {
            $mirrorCameraInterior = ($data.mirrorCameraInterior -eq $true)
        }

        $dynamicDesired = ($null -ne $data.dynamicEnabled -and $data.dynamicEnabled -eq $true)
        $planeDesired = ($null -ne $data.planeEnabled -and $data.planeEnabled -eq $true)
        $shadowDesired = ($null -ne $data.shadowEnabled -and $data.shadowEnabled -eq $true)
        $pssm6Desired = ($null -ne $data.pssm6Enabled -and $data.pssm6Enabled -eq $true)
        $casterDesired = ($null -ne $data.casterMaskEnabled -and $data.casterMaskEnabled -eq $true)
        $split3Desired = ($null -ne $data.split3Enabled -and $data.split3Enabled -eq $true)

        [Int64]$heartbeat = 0
        if ($null -ne $data.heartbeat) {
            [Int64]::TryParse([string]$data.heartbeat, [ref]$heartbeat) | Out-Null
        }

        return [pscustomobject]@{
            MirrorDesired = $mirrorDesired
            MirrorPreferenceDesired = $mirrorPreferenceDesired
            MirrorDivisor = $mirrorDivisor
            MirrorAutoViewEnabled = $mirrorAutoViewEnabled
            MirrorCameraName = $mirrorCameraName
            MirrorCameraInterior = $mirrorCameraInterior
            DynamicDesired = $dynamicDesired
            DynamicDivisor = $dynamicDivisor
            PlaneDesired = $planeDesired
            PlaneDivisor = $planeDivisor
            ShadowDesired = $shadowDesired
            ShadowDivisor = $shadowDivisor
            Pssm6Desired = $pssm6Desired
            CasterDesired = $casterDesired
            Split3Desired = $split3Desired
            Heartbeat = $heartbeat
            LastWriteUtc = $item.LastWriteTimeUtc
        }
    }
    catch {
        $script:LastError = "control read failed: $($_.Exception.Message)"
        $script:LastAction = 'control-read-failed'
        $script:PlaneLastError = $script:LastError
        $script:PlaneLastAction = 'control-read-failed'
        $script:ShadowLastError = $script:LastError
        $script:ShadowLastAction = 'control-read-failed'
        $script:Pssm6LastError = $script:LastError
        $script:Pssm6LastAction = 'control-read-failed'
        $script:CasterLastError = $script:LastError
        $script:CasterLastAction = 'control-read-failed'
        $script:Split3LastError = $script:LastError
        $script:Split3LastAction = 'control-read-failed'
        return $null
    }
}

function Update-ShadowCounters {
    if (-not $script:ShadowHookActive -or $script:ShadowHandle -eq [IntPtr]::Zero) { return }
    try {
        $script:ShadowTotalCalls = Read-RemoteUInt32 -Handle $script:ShadowHandle -Address ($script:ShadowRemoteBase + 0x308)
        $script:ShadowFullCalls = Read-RemoteUInt32 -Handle $script:ShadowHandle -Address ($script:ShadowRemoteBase + 0x30C)
    }
    catch {
        $script:ShadowLastError = "counter read failed: $($_.Exception.Message)"
    }
}

function Write-BridgeStatus {
    if (-not $script:StatusPath) { return }

    Update-ShadowCounters
    $script:StatusSequence++

    [int]$pidOut = 0
    if ($script:GamePid -ne 0) { $pidOut = [int]$script:GamePid }
    elseif ($script:PlaneGamePid -ne 0) { $pidOut = [int]$script:PlaneGamePid }
    elseif ($script:ShadowGamePid -ne 0) { $pidOut = [int]$script:ShadowGamePid }
    elseif ($script:Pssm6GamePid -ne 0) { $pidOut = [int]$script:Pssm6GamePid }
    elseif ($script:CasterGamePid -ne 0) { $pidOut = [int]$script:CasterGamePid }
    elseif ($script:Split3GamePid -ne 0) { $pidOut = [int]$script:Split3GamePid }

    $payload = [ordered]@{
        protocol = 6
        sequence = [Int64]$script:StatusSequence
        helperOnline = $true
        build = 'pattern-scan; baseline 0.39.4.0.20972 Win64'
        pid = $pidOut
        bridgePid = [int]$PID
        mirror = [ordered]@{
            available = [bool]$script:Available
            buildValid = [bool]$script:BuildValid
            active = [bool]($script:HookActive -and $script:MirrorThrottleActive)
            divisor = [int]$script:ActiveMirrorDivisor
            mirrorCount = [int]$script:MirrorCount
            viewMode = [string]$script:MirrorViewMode
            cameraName = [string]$script:MirrorCameraName
            cameraInterior = $script:MirrorCameraInterior
            autoViewEnabled = [bool]$script:MirrorAutoViewEnabled
            savedInteriorEnabled = [bool]$script:MirrorPreferenceDesired
            waitingForMirrors = [bool](
                $script:MirrorAutoViewEnabled -and
                $script:MirrorCameraInterior -eq $true -and
                $script:MirrorPreferenceDesired -and
                -not $script:HookActive
            )
            cubeCount = [int]$script:CubeCount
            dispatcherBytes = [int]$script:DispatcherBytes
            rebuilds = [int]$script:Rebuilds
            lastError = [string]$script:LastError
            lastAction = [string]$script:LastAction
        }
        dynamic = [ordered]@{
            available = [bool]$script:Available
            buildValid = [bool]$script:BuildValid
            active = [bool]($script:HookActive -and $script:DynamicThrottleActive)
            divisor = [int]$script:ActiveDynamicDivisor
            objectCount = [int]$script:DynamicCount
            dispatcherBytes = [int]$script:DispatcherBytes
            rebuilds = [int]$script:Rebuilds
            lastError = [string]$script:LastError
            lastAction = [string]$script:LastAction
        }
        plane = [ordered]@{
            available = [bool]$script:PlaneAvailable
            buildValid = [bool]$script:PlaneBuildValid
            active = [bool]$script:PlaneHookActive
            divisor = [int]$script:PlaneActiveDivisor
            objectCount = [int]$script:PlaneCount
            dispatcherBytes = [int]$script:PlaneDispatcherBytes
            rebuilds = [int]$script:PlaneRebuilds
            lastError = [string]$script:PlaneLastError
            lastAction = [string]$script:PlaneLastAction
        }
        shadow = [ordered]@{
            available = [bool]$script:ShadowAvailable
            buildValid = [bool]$script:ShadowBuildValid
            active = [bool]$script:ShadowHookActive
            divisor = [int]$script:ShadowActiveDivisor
            dispatcherBytes = [int]$script:ShadowDispatcherBytes
            totalCalls = [UInt32]$script:ShadowTotalCalls
            fullCalls = [UInt32]$script:ShadowFullCalls
            vehicleFullRate = [bool]$script:ShadowHookActive
            rebuilds = [int]$script:ShadowRebuilds
            lastError = [string]$script:ShadowLastError
            lastAction = [string]$script:ShadowLastAction
        }
        pssm6 = [ordered]@{
            available = [bool]$script:Pssm6Available
            buildValid = [bool]$script:Pssm6BuildValid
            active = [bool]$script:Pssm6Active
            value = [double]$(if($script:Pssm6Active){6.0}else{0.0})
            lastError = [string]$script:Pssm6LastError
            lastAction = [string]$script:Pssm6LastAction
        }
        caster = [ordered]@{
            available = [bool]$script:CasterAvailable
            buildValid = [bool]$script:CasterBuildValid
            active = [bool]$script:CasterActive
            mask = [string]$(if($script:CasterActive){'0x100'}else{'0x300'})
            lastError = [string]$script:CasterLastError
            lastAction = [string]$script:CasterLastAction
        }
        split3 = [ordered]@{
            available = [bool]$script:Split3Available
            buildValid = [bool]$script:Split3BuildValid
            active = [bool]$script:Split3Active
            splitCount = [int]$(if($script:Split3Active){3}else{4})
            lastError = [string]$script:Split3LastError
            lastAction = [string]$script:Split3LastAction
        }
        utc = [DateTime]::UtcNow.ToString('o')
    }

    try {
        $json = $payload | ConvertTo-Json -Depth 7
        $tmp = $script:StatusPath + '.tmp'
        [IO.File]::WriteAllText($tmp, $json, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $tmp -Destination $script:StatusPath -Force
    }
    catch { }
}

function Reset-HookState {
    $script:Handle = [IntPtr]::Zero
    $script:RemotePage = [IntPtr]::Zero
    [UInt64]$script:RemoteBase = 0
    [UInt64]$script:SlotAddress = 0
    [UInt64]$script:OriginalTarget = 0
    [UInt64]$script:ModuleBase = 0
    $script:ModulePath = ''
    [UInt64]$script:Manager = 0
    $script:GamePid = 0
    $script:GameProcess = $null
    $script:HookActive = $false
    $script:Available = $false
    $script:BuildValid = $false
    $script:MirrorCount = 0
    $script:DynamicCount = 0
    $script:CubeCount = 0
    $script:DispatcherBytes = 0
    $script:MirrorThrottleActive = $false
    $script:DynamicThrottleActive = $false
    $script:MirrorAutoViewEnabled = $true
    $script:MirrorViewMode = 'unknown'
    $script:MirrorCameraName = 'unknown'
    $script:MirrorCameraInterior = $null
    $script:MirrorPreferenceDesired = $false
    $script:ActiveMirrorDivisor = 0
    $script:ActiveDynamicDivisor = 0
    [UInt64[]]$script:Mirrors = @()
    [UInt64[]]$script:Dynamics = @()
}

function Restore-Hook {
    param([string]$Reason = 'disabled')

    if (-not $script:HookActive) {
        if ($script:Handle -ne [IntPtr]::Zero) {
            if ($script:RemotePage -ne [IntPtr]::Zero) {
                try {
                    Start-Sleep -Milliseconds 100
                    [void][BeamNGMirrorRateTest039]::VirtualFreeEx(
                        $script:Handle,$script:RemotePage,[UIntPtr]::Zero,[UInt32]0x8000)
                } catch { }
            }
            [void][BeamNGMirrorRateTest039]::CloseHandle($script:Handle)
        }
        Reset-HookState
        $script:LastAction = $Reason
        return $true
    }

    $alive = ($script:GamePid -ne 0 -and
        $null -ne (Get-Process -Id $script:GamePid -ErrorAction SilentlyContinue))
    if (-not $alive) {
        Reset-HookState
        $script:LastAction = 'game-exited'
        $script:LastError = 'none'
        return $true
    }

    try {
        [UInt64]$current = Read-RemoteUInt64 -Handle $script:Handle -Address $script:SlotAddress
        if ($current -eq $script:RemoteBase) {
            Write-ProtectedRemoteBytes `
                -Handle $script:Handle `
                -Address $script:SlotAddress `
                -Data ([BitConverter]::GetBytes($script:OriginalTarget))
        }
        elseif ($current -ne $script:OriginalTarget) {
            $script:LastError = "restore refused: CubeReflector slot owned by another hook ($(Format-HexAddress $current))"
            $script:LastAction = 'restore-conflict'
            return $false
        }

        if ((Read-RemoteUInt64 -Handle $script:Handle -Address $script:SlotAddress) -ne $script:OriginalTarget) {
            $script:LastError = 'CubeReflector restore verification failed; exit BeamNG'
            $script:LastAction = 'restore-failed'
            return $false
        }

        Start-Sleep -Milliseconds 100
        if ($script:RemotePage -ne [IntPtr]::Zero) {
            [void][BeamNGMirrorRateTest039]::VirtualFreeEx(
                $script:Handle,$script:RemotePage,[UIntPtr]::Zero,[UInt32]0x8000)
        }
        if ($script:Handle -ne [IntPtr]::Zero) {
            [void][BeamNGMirrorRateTest039]::CloseHandle($script:Handle)
        }

        Reset-HookState
        $script:LastError = 'none'
        $script:LastAction = $Reason
        return $true
    }
    catch {
        $script:LastError = "CubeReflector restore error: $($_.Exception.Message); exit BeamNG"
        $script:LastAction = 'restore-error'
        return $false
    }
}

function Install-Hook {
    param(
        [bool]$MirrorDesired,
        [int]$MirrorDivisor,
        [bool]$MirrorAutoViewEnabled,
        [bool]$DynamicDesired,
        [int]$DynamicDivisor
    )

    if (-not $MirrorDesired -and -not $DynamicDesired) {
        return (Restore-Hook -Reason 'cube-native')
    }

    if ($MirrorDivisor -lt 2) { $MirrorDivisor = 2 }
    if ($MirrorDivisor -gt 8) { $MirrorDivisor = 8 }
    if ($DynamicDivisor -lt 2) { $DynamicDivisor = 2 }
    if ($DynamicDivisor -gt 8) { $DynamicDivisor = 8 }

    if ($script:HookActive) {
        $sameConfig = (
            $script:MirrorThrottleActive -eq $MirrorDesired -and
            $script:DynamicThrottleActive -eq $DynamicDesired -and
            (-not $MirrorDesired -or $script:ActiveMirrorDivisor -eq $MirrorDivisor) -and
            (-not $DynamicDesired -or $script:ActiveDynamicDivisor -eq $DynamicDivisor)
        )
        if ($sameConfig) { return $true }
        if (-not (Restore-Hook -Reason 'cube-reconfigure')) { return $false }
    }

    [IntPtr]$handle = [IntPtr]::Zero
    [IntPtr]$remotePageLocal = [IntPtr]::Zero
    [UInt64]$remoteBaseLocal = 0
    [UInt64]$slotAddressLocal = 0
    [UInt64]$originalTargetLocal = 0

    try {
        $selection = Get-BeamNGSelection -RequestedProcessId 0
        $gameProcess = $selection.Process
        $mainModule = $selection.MainModule
        [UInt64]$moduleBase = [UInt64]$mainModule.BaseAddress.ToInt64()
        $fileInfo = Get-Item -LiteralPath $mainModule.FileName

        # Version-flexible mode: no executable-size/version gate.
        # Per-hook native signature/vtable checks below remain mandatory.

        $access = [UInt32](0x0008 -bor 0x0010 -bor 0x0020 -bor 0x0400)
        $handle = [BeamNGMirrorRateTest039]::OpenProcess($access,$false,$gameProcess.Id)
        if ($handle -eq [IntPtr]::Zero) { throw 'OpenProcess failed for CubeReflector hook' }

        $topology = Get-ReflectorTopology `
            -Handle $handle `
            -ModuleBase $moduleBase `
            -ExePath $mainModule.FileName

        if ([UInt64]$topology.FaceCountStoreRva -ne 0) {
            [byte[]]$expectedFaceStore = Convert-HexStringToBytes $ExpectedFaceCountStoreHex
            [byte[]]$liveFaceStore = Read-RemoteBytes `
                -Handle $handle `
                -Address ($moduleBase + [UInt64]$topology.FaceCountStoreRva) `
                -Count $expectedFaceStore.Length

            if (-not (Test-ByteArraysEqual $expectedFaceStore $liveFaceStore)) {
                throw 'legacy face-cap patch is still active at the pattern-resolved face-count store'
            }
        }

        $targets = New-Object System.Collections.Generic.List[UInt64]
        $divisors = New-Object System.Collections.Generic.List[int]

        if ($MirrorDesired) {
            foreach ($o in @($topology.Mirrors)) {
                $targets.Add([UInt64]$o)
                $divisors.Add($MirrorDivisor)
            }
        }

        if ($DynamicDesired) {
            foreach ($o in @($topology.Dynamic)) {
                $targets.Add([UInt64]$o)
                $divisors.Add($DynamicDivisor)
            }
        }

        if ($targets.Count -lt 1) {
            $mirrorCountNow = @($topology.Mirrors).Count
            $dynamicCountNow = @($topology.Dynamic).Count

            if ($MirrorDesired -and $mirrorCountNow -eq 0) {
                throw 'interior mirror CubeReflectors were not found yet'
            }
            if ($DynamicDesired -and $dynamicCountNow -eq 0) {
                throw 'vehicle dynamic-reflection CubeReflector was not found'
            }
            throw 'no requested CubeReflector targets were found'
        }

        if ([UInt64]$topology.CubeVtable -eq 0) {
            throw 'CubeReflector RTTI vtable was not resolved'
        }

        [UInt64]$slotAddress = [UInt64]$topology.CubeVtable + 0x18
        [UInt64]$originalTarget = Read-RemoteUInt64 -Handle $handle -Address $slotAddress

        if (-not (Test-ModuleTextAddress `
            -Context $topology.ScanContext `
            -ModuleBase $moduleBase `
            -Address $originalTarget)) {
            throw "CubeReflector selected-update slot does not point into BeamNG .text ($(Format-HexAddress $originalTarget)); stop other native hooks first"
        }

        $slotAddressLocal = $slotAddress
        $originalTargetLocal = $originalTarget

        $remotePage = [BeamNGMirrorRateTest039]::VirtualAllocEx(
            $handle,[IntPtr]::Zero,[UIntPtr]([UInt64]0x8000),[UInt32]0x3000,[UInt32]0x40)
        if ($remotePage -eq [IntPtr]::Zero) { throw 'VirtualAllocEx failed for CubeReflector dispatcher' }

        [UInt64]$remoteBase = [UInt64]$remotePage.ToInt64()
        $remotePageLocal = $remotePage
        $remoteBaseLocal = $remoteBase

        [byte[]]$dispatcher = New-ObjectRateDispatcher `
            -TargetObjects ([UInt64[]]$targets.ToArray()) `
            -TargetDivisors ([int[]]$divisors.ToArray()) `
            -OriginalTarget $originalTarget `
            -RemoteBase $remoteBase

        Write-RemoteBytes -Handle $handle -Address $remoteBase -Data $dispatcher
        Initialize-DispatcherCounters `
            -Handle $handle `
            -RemoteBase $remoteBase `
            -Divisors ([int[]]$divisors.ToArray())

        [void][BeamNGMirrorRateTest039]::FlushInstructionCache(
            $handle,$remotePage,[UIntPtr]([UInt64]$dispatcher.Length))

        Write-ProtectedRemoteBytes `
            -Handle $handle `
            -Address $slotAddress `
            -Data ([BitConverter]::GetBytes($remoteBase))

        if ((Read-RemoteUInt64 -Handle $handle -Address $slotAddress) -ne $remoteBase) {
            throw 'CubeReflector vtable hook verification failed'
        }

        $script:Handle = $handle
        $script:RemotePage = $remotePage
        $script:RemoteBase = $remoteBase
        $script:SlotAddress = $slotAddress
        $script:OriginalTarget = $originalTarget
        $script:ModuleBase = $moduleBase
        $script:ModulePath = $mainModule.FileName
        $script:Manager = [UInt64]$topology.Manager
        $script:GamePid = [int]$gameProcess.Id
        $script:GameProcess = $gameProcess
        $script:HookActive = $true
        $script:Available = $true
        $script:BuildValid = $true
        $script:MirrorCount = @($topology.Mirrors).Count
        $script:DynamicCount = @($topology.Dynamic).Count
        $script:CubeCount = $topology.CubeCount
        $script:DispatcherBytes = $dispatcher.Length
        $script:MirrorThrottleActive = $MirrorDesired
        $script:DynamicThrottleActive = $DynamicDesired
        $script:MirrorAutoViewEnabled = $MirrorAutoViewEnabled
        # View mode is supplied by BeamNG core_camera through the Lua control
        # file; mirror count is diagnostic only.
        $script:ActiveMirrorDivisor = $(if ($MirrorDesired) { $MirrorDivisor } else { 0 })
        $script:ActiveDynamicDivisor = $(if ($DynamicDesired) { $DynamicDivisor } else { 0 })
        [UInt64[]]$script:Mirrors = @($topology.Mirrors)
        [UInt64[]]$script:Dynamics = @($topology.Dynamic)
        $script:LastError = 'none'
        $script:LastAction = 'installed'

        Write-Host ("[BeamOpt] CUBE ACTIVE | mirrors={0} {1} | dynamic={2} {3}" -f `
            $script:MirrorCount,
            $(if ($MirrorDesired) { "1/$MirrorDivisor" } else { 'native' }),
            $script:DynamicCount,
            $(if ($DynamicDesired) { "1/$DynamicDivisor" } else { 'native' }))
        return $true
    }
    catch {
        $installError = $_.Exception.Message

        if ($handle -ne [IntPtr]::Zero) {
            try {
                if ($slotAddressLocal -ne 0 -and $originalTargetLocal -ne 0 -and $remoteBaseLocal -ne 0) {
                    if ((Read-RemoteUInt64 -Handle $handle -Address $slotAddressLocal) -eq $remoteBaseLocal) {
                        Write-ProtectedRemoteBytes `
                            -Handle $handle `
                            -Address $slotAddressLocal `
                            -Data ([BitConverter]::GetBytes($originalTargetLocal))
                        Start-Sleep -Milliseconds 100
                    }
                }
            } catch { }

            if ($remotePageLocal -ne [IntPtr]::Zero) {
                try {
                    [void][BeamNGMirrorRateTest039]::VirtualFreeEx(
                        $handle,$remotePageLocal,[UIntPtr]::Zero,[UInt32]0x8000)
                } catch { }
            }
            [void][BeamNGMirrorRateTest039]::CloseHandle($handle)
        }

        $script:LastError = $installError
        $script:LastAction = 'install-failed'
        $script:Available = $false
        $script:BuildValid = $false
        Write-Warning "[BeamOpt] CubeReflector: $installError"
        return $false
    }
}

function Validate-ActiveHook {
    if (-not $script:HookActive) { return $false }

    if ($script:GamePid -eq 0 -or
        $null -eq (Get-Process -Id $script:GamePid -ErrorAction SilentlyContinue)) {
        Reset-HookState
        $script:LastError = 'none'
        $script:LastAction = 'game-exited'
        return $false
    }

    try {
        if ((Read-RemoteUInt64 -Handle $script:Handle -Address $script:SlotAddress) -ne $script:RemoteBase) {
            $script:LastError = 'CubeReflector hook disappeared or was replaced'
            $script:LastAction = 'hook-lost'
            $script:HookActive = $false
            return $false
        }

        $topology = Get-ReflectorTopology -Handle $script:Handle -ModuleBase $script:ModuleBase -ExePath $script:ModulePath
        [UInt64[]]$liveMirrors = @($topology.Mirrors)
        [UInt64[]]$liveDynamics = @($topology.Dynamic)

        if ([UInt64]$topology.Manager -ne $script:Manager -or
            -not (Test-SameUInt64Set -A $script:Mirrors -B $liveMirrors) -or
            -not (Test-SameUInt64Set -A $script:Dynamics -B $liveDynamics)) {
            if (Restore-Hook -Reason 'reflector-set-changed') {
                $script:Rebuilds++
            }
            return $false
        }

        $script:MirrorCount = $liveMirrors.Count
        $script:DynamicCount = $liveDynamics.Count
        $script:CubeCount = $topology.CubeCount
        return $true
    }
    catch {
        $script:LastError = "CubeReflector validation failed: $($_.Exception.Message)"
        $script:LastAction = 'validation-failed'
        Restore-Hook -Reason 'validation-failed' | Out-Null
        return $false
    }
}

# ---------------- plane-reflector hook ----------------

function Reset-PlaneHookState {
    $script:PlaneHandle = [IntPtr]::Zero
    $script:PlaneRemotePage = [IntPtr]::Zero
    [UInt64]$script:PlaneRemoteBase = 0
    [UInt64]$script:PlaneSlotAddress = 0
    [UInt64]$script:PlaneOriginalTarget = 0
    [UInt64]$script:PlaneModuleBase = 0
    $script:PlaneModulePath = ''
    [UInt64]$script:PlaneManager = 0
    $script:PlaneGamePid = 0
    $script:PlaneHookActive = $false
    $script:PlaneAvailable = $false
    $script:PlaneBuildValid = $false
    $script:PlaneCount = 0
    $script:PlaneDispatcherBytes = 0
    $script:PlaneActiveDivisor = 0
    [UInt64[]]$script:PlaneObjects = @()
}

function Restore-PlaneHook {
    param([string]$Reason = 'disabled')

    if (-not $script:PlaneHookActive) {
        if ($script:PlaneHandle -ne [IntPtr]::Zero) {
            if ($script:PlaneRemotePage -ne [IntPtr]::Zero) {
                try {
                    Start-Sleep -Milliseconds 100
                    [void][BeamNGMirrorRateTest039]::VirtualFreeEx(
                        $script:PlaneHandle,$script:PlaneRemotePage,[UIntPtr]::Zero,[UInt32]0x8000)
                } catch { }
            }
            [void][BeamNGMirrorRateTest039]::CloseHandle($script:PlaneHandle)
        }
        Reset-PlaneHookState
        $script:PlaneLastAction = $Reason
        return $true
    }

    $alive = ($script:PlaneGamePid -ne 0 -and
        $null -ne (Get-Process -Id $script:PlaneGamePid -ErrorAction SilentlyContinue))
    if (-not $alive) {
        Reset-PlaneHookState
        $script:PlaneLastAction = 'game-exited'
        $script:PlaneLastError = 'none'
        return $true
    }

    try {
        [UInt64]$current = Read-RemoteUInt64 -Handle $script:PlaneHandle -Address $script:PlaneSlotAddress
        if ($current -eq $script:PlaneRemoteBase) {
            Write-ProtectedRemoteBytes `
                -Handle $script:PlaneHandle `
                -Address $script:PlaneSlotAddress `
                -Data ([BitConverter]::GetBytes($script:PlaneOriginalTarget))
        }
        elseif ($current -ne $script:PlaneOriginalTarget) {
            $script:PlaneLastError = 'PlaneReflector restore refused: slot owned by another hook'
            $script:PlaneLastAction = 'restore-conflict'
            return $false
        }

        if ((Read-RemoteUInt64 -Handle $script:PlaneHandle -Address $script:PlaneSlotAddress) -ne $script:PlaneOriginalTarget) {
            $script:PlaneLastError = 'PlaneReflector restore verification failed; exit BeamNG'
            $script:PlaneLastAction = 'restore-failed'
            return $false
        }

        Start-Sleep -Milliseconds 100
        if ($script:PlaneRemotePage -ne [IntPtr]::Zero) {
            [void][BeamNGMirrorRateTest039]::VirtualFreeEx(
                $script:PlaneHandle,$script:PlaneRemotePage,[UIntPtr]::Zero,[UInt32]0x8000)
        }
        if ($script:PlaneHandle -ne [IntPtr]::Zero) {
            [void][BeamNGMirrorRateTest039]::CloseHandle($script:PlaneHandle)
        }

        Reset-PlaneHookState
        $script:PlaneLastError = 'none'
        $script:PlaneLastAction = $Reason
        return $true
    }
    catch {
        $script:PlaneLastError = "PlaneReflector restore error: $($_.Exception.Message); exit BeamNG"
        $script:PlaneLastAction = 'restore-error'
        return $false
    }
}

function Install-PlaneHook {
    param([int]$Divisor)

    if ($Divisor -lt 2) { $Divisor = 2 }
    if ($Divisor -gt 8) { $Divisor = 8 }

    if ($script:PlaneHookActive) {
        if ($script:PlaneActiveDivisor -eq $Divisor) { return $true }
        if (-not (Restore-PlaneHook -Reason 'plane-reconfigure')) { return $false }
    }

    [IntPtr]$handle = [IntPtr]::Zero
    [IntPtr]$page = [IntPtr]::Zero
    [UInt64]$slotAddress = 0
    [UInt64]$originalTarget = 0
    [UInt64]$remoteBase = 0

    try {
        $selection = Get-BeamNGSelection -RequestedProcessId 0
        $gameProcess = $selection.Process
        $mainModule = $selection.MainModule
        [UInt64]$moduleBase = [UInt64]$mainModule.BaseAddress.ToInt64()
        $fileInfo = Get-Item -LiteralPath $mainModule.FileName
# Version-flexible mode: executable size is informational only; local native validation is authoritative.

        $access = [UInt32](0x0008 -bor 0x0010 -bor 0x0020 -bor 0x0400)
        $handle = [BeamNGMirrorRateTest039]::OpenProcess($access,$false,$gameProcess.Id)
        if ($handle -eq [IntPtr]::Zero) { throw 'OpenProcess failed for PlaneReflector hook' }

        $topology = Get-ReflectorTopology -Handle $handle -ModuleBase $moduleBase -ExePath $mainModule.FileName
        [UInt64[]]$planes = @($topology.Planes)
        if ($planes.Count -lt 1) { throw 'no PlaneReflectors are currently registered' }

        if ([UInt64]$topology.PlaneVtable -eq 0) {
            throw 'PlaneReflector RTTI vtable was not resolved'
        }

        $slotAddress = [UInt64]$topology.PlaneVtable + 0x18
        $originalTarget = Read-RemoteUInt64 -Handle $handle -Address $slotAddress

        if (-not (Test-ModuleTextAddress `
            -Context $topology.ScanContext `
            -ModuleBase $moduleBase `
            -Address $originalTarget)) {
            throw "PlaneReflector selected-update slot does not point into BeamNG .text ($(Format-HexAddress $originalTarget)); stop other native hooks first"
        }

        $page = [BeamNGMirrorRateTest039]::VirtualAllocEx(
            $handle,[IntPtr]::Zero,[UIntPtr]([UInt64]0x8000),[UInt32]0x3000,[UInt32]0x40)
        if ($page -eq [IntPtr]::Zero) { throw 'VirtualAllocEx failed for PlaneReflector dispatcher' }

        $remoteBase = [UInt64]$page.ToInt64()
        [int[]]$divisors = @($planes | ForEach-Object { $Divisor })

        [byte[]]$dispatcher = New-ObjectRateDispatcher `
            -TargetObjects $planes `
            -TargetDivisors $divisors `
            -OriginalTarget $originalTarget `
            -RemoteBase $remoteBase

        Write-RemoteBytes -Handle $handle -Address $remoteBase -Data $dispatcher
        Initialize-DispatcherCounters -Handle $handle -RemoteBase $remoteBase -Divisors $divisors

        [void][BeamNGMirrorRateTest039]::FlushInstructionCache(
            $handle,$page,[UIntPtr]([UInt64]$dispatcher.Length))

        Write-ProtectedRemoteBytes `
            -Handle $handle `
            -Address $slotAddress `
            -Data ([BitConverter]::GetBytes($remoteBase))

        if ((Read-RemoteUInt64 -Handle $handle -Address $slotAddress) -ne $remoteBase) {
            throw 'PlaneReflector vtable hook verification failed'
        }

        $script:PlaneHandle = $handle
        $script:PlaneRemotePage = $page
        $script:PlaneRemoteBase = $remoteBase
        $script:PlaneSlotAddress = $slotAddress
        $script:PlaneOriginalTarget = $originalTarget
        $script:PlaneModuleBase = $moduleBase
        $script:PlaneModulePath = $mainModule.FileName
        $script:PlaneManager = [UInt64]$topology.Manager
        $script:PlaneGamePid = [int]$gameProcess.Id
        $script:PlaneHookActive = $true
        $script:PlaneAvailable = $true
        $script:PlaneBuildValid = $true
        $script:PlaneCount = $planes.Count
        $script:PlaneDispatcherBytes = $dispatcher.Length
        $script:PlaneActiveDivisor = $Divisor
        [UInt64[]]$script:PlaneObjects = @($planes)
        $script:PlaneLastError = 'none'
        $script:PlaneLastAction = 'installed'

        Write-Host ("[BeamOpt] PLANE ACTIVE 1/{0} | reflectors={1}" -f $Divisor,$planes.Count)
        return $true
    }
    catch {
        $err = $_.Exception.Message

        if ($handle -ne [IntPtr]::Zero) {
            try {
                if ($slotAddress -ne 0 -and $originalTarget -ne 0 -and $remoteBase -ne 0) {
                    if ((Read-RemoteUInt64 -Handle $handle -Address $slotAddress) -eq $remoteBase) {
                        Write-ProtectedRemoteBytes `
                            -Handle $handle `
                            -Address $slotAddress `
                            -Data ([BitConverter]::GetBytes($originalTarget))
                        Start-Sleep -Milliseconds 100
                    }
                }
            } catch { }

            if ($page -ne [IntPtr]::Zero) {
                try {
                    [void][BeamNGMirrorRateTest039]::VirtualFreeEx(
                        $handle,$page,[UIntPtr]::Zero,[UInt32]0x8000)
                } catch { }
            }
            [void][BeamNGMirrorRateTest039]::CloseHandle($handle)
        }

        $script:PlaneLastError = $err
        $script:PlaneLastAction = 'install-failed'
        $script:PlaneAvailable = $false
        $script:PlaneBuildValid = $false
        Write-Warning "[BeamOpt] PlaneReflector: $err"
        return $false
    }
}

function Validate-PlaneHook {
    if (-not $script:PlaneHookActive) { return $false }

    if ($script:PlaneGamePid -eq 0 -or
        $null -eq (Get-Process -Id $script:PlaneGamePid -ErrorAction SilentlyContinue)) {
        Reset-PlaneHookState
        $script:PlaneLastError = 'none'
        $script:PlaneLastAction = 'game-exited'
        return $false
    }

    try {
        if ((Read-RemoteUInt64 -Handle $script:PlaneHandle -Address $script:PlaneSlotAddress) -ne $script:PlaneRemoteBase) {
            $script:PlaneLastError = 'PlaneReflector hook disappeared or was replaced'
            $script:PlaneLastAction = 'hook-lost'
            $script:PlaneHookActive = $false
            return $false
        }

        $topology = Get-ReflectorTopology `
            -Handle $script:PlaneHandle `
            -ModuleBase $script:PlaneModuleBase `
            -ExePath $script:PlaneModulePath
        [UInt64[]]$livePlanes = @($topology.Planes)

        if ([UInt64]$topology.Manager -ne $script:PlaneManager -or
            -not (Test-SameUInt64Set -A $script:PlaneObjects -B $livePlanes)) {
            if (Restore-PlaneHook -Reason 'reflector-set-changed') {
                $script:PlaneRebuilds++
            }
            return $false
        }

        $script:PlaneCount = $livePlanes.Count
        return $true
    }
    catch {
        $script:PlaneLastError = "PlaneReflector validation failed: $($_.Exception.Message)"
        $script:PlaneLastAction = 'validation-failed'
        Restore-PlaneHook -Reason 'validation-failed' | Out-Null
        return $false
    }
}

# ---------------- selective world-shadow hook ----------------
function Allocate-NearShadowTarget {
param([IntPtr]$Handle,[UInt64]$TargetAddress)
$MEM_FREE=[UInt32]0x10000
$MEM_COMMIT_RESERVE=[UInt32]0x3000
$PAGE_EXECUTE_READWRITE=[UInt32]0x40
[UInt64]$searchRadius=[UInt64]0x70000000
[UInt64]$minAddress=[UInt64]0x10000
[UInt64]$lower=$minAddress
if($TargetAddress -gt $searchRadius){$lower=$TargetAddress-$searchRadius}
[UInt64]$upper=$TargetAddress+$searchRadius
[UInt64]$cursor=$lower
[UInt64]$alignmentMask=[UInt64]::MaxValue-[UInt64]0xFFFF
$mbiSize=[Runtime.InteropServices.Marshal]::SizeOf([type][BeamNGMirrorRateTest039+MEMORY_BASIC_INFORMATION])
while($cursor -lt $upper){
$mbi=New-Object BeamNGMirrorRateTest039+MEMORY_BASIC_INFORMATION
[UIntPtr]$queried=[BeamNGMirrorRateTest039]::VirtualQueryEx(
$Handle,[IntPtr]([Int64]$cursor),[ref]$mbi,[UIntPtr]([UInt64]$mbiSize))
if($queried -eq [UIntPtr]::Zero){break}
[UInt64]$base=[UInt64]$mbi.BaseAddress.ToInt64()
[UInt64]$size=$mbi.RegionSize.ToUInt64()
if($size -eq 0){break}
if($mbi.State -eq $MEM_FREE -and $size -ge 0x1000){
[UInt64]$candidate=([UInt64]$base+[UInt64]0xFFFF) -band $alignmentMask
if($candidate -ge $lower -and $candidate -lt $upper -and
($candidate+0x1000) -le ($base+$size)){
[Int64]$rel=[Int64]$candidate-([Int64]$TargetAddress+5)
if($rel -ge [Int32]::MinValue -and $rel -le [Int32]::MaxValue){
$page=[BeamNGMirrorRateTest039]::VirtualAllocEx(
$Handle,[IntPtr]([Int64]$candidate),[UIntPtr]([UInt64]0x1000),
$MEM_COMMIT_RESERVE,$PAGE_EXECUTE_READWRITE)
if($page -ne [IntPtr]::Zero){return $page}
}
}
}
[UInt64]$next=$base+$size
if($next -le $cursor){break}
$cursor=$next
}
throw 'could not allocate executable memory within rel32 range of the PSSM hook'
}
function New-AbsJumpBytes {
param([UInt64]$TargetAddress,[ValidateSet('rax','r11')][string]$Register='rax')
$code=New-Object System.Collections.Generic.List[byte]
if($Register -eq 'r11'){
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $TargetAddress
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xFF,0xE3))
}else{
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xB8))
Add-CodeUInt64 -Code $code -Value $TargetAddress
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xFF,0xE0))
}
return ,$code.ToArray()
}
function New-ShadowLoopDispatcher {
param([UInt64]$RemoteBase,[UInt64]$ContinueAddress,[UInt64]$SkipAddress)
$code=New-Object System.Collections.Generic.List[byte]
[UInt64]$fullFlag=$RemoteBase+[UInt64]0x304
[UInt64]$cacheA=$RemoteBase+[UInt64]0x400
[UInt64]$cacheB=$RemoteBase+[UInt64]0x500
[UInt64]$cacheC=$RemoteBase+[UInt64]0x600
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0x53))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $fullFlag
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0x80,0x3B,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0x5B))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x0F,0x84))
[int]$skipDispOffset=$code.Count
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0,0,0,0))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x51,0x56,0x57))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0x8D,0xB7,0x00,0x01,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xBF))
Add-CodeUInt64 -Code $code -Value $cacheA
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xB9,0x80,0x00,0x00,0x00,0xF3,0xA4))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0x8D,0xB7,0xB8,0x01,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xBF))
Add-CodeUInt64 -Code $code -Value $cacheB
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xB9,0x18,0x00,0x00,0x00,0xF3,0xA4))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0x8D,0xB5,0xE0,0x04,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xBF))
Add-CodeUInt64 -Code $code -Value $cacheC
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xB9,0x10,0x00,0x00,0x00,0xF3,0xA4))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x5F,0x5E,0x59))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0x39,0xBF,0xB8,0x01,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x0F,0x86))
[int]$nativeSkipDispOffset=$code.Count
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0,0,0,0))
Add-CodeBytes -Code $code -Bytes (New-AbsJumpBytes -TargetAddress $ContinueAddress -Register 'rax')
[int]$skipOffset=$code.Count
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x51,0x56,0x57))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xBE))
Add-CodeUInt64 -Code $code -Value $cacheA
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0x8D,0xBF,0x00,0x01,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xB9,0x80,0x00,0x00,0x00,0xF3,0xA4))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xBE))
Add-CodeUInt64 -Code $code -Value $cacheB
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0x8D,0xBF,0xB8,0x01,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xB9,0x18,0x00,0x00,0x00,0xF3,0xA4))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0xBE))
Add-CodeUInt64 -Code $code -Value $cacheC
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x48,0x8D,0xBD,0xE0,0x04,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xB9,0x10,0x00,0x00,0x00,0xF3,0xA4))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x5F,0x5E,0x59))
Add-CodeBytes -Code $code -Bytes (New-AbsJumpBytes -TargetAddress $SkipAddress -Register 'rax')
[byte[]]$result=$code.ToArray()
Set-RelativeInt32 -Code $result -DisplacementOffset $skipDispOffset -TargetOffset $skipOffset
[Int64]$nativeDisp64=[Int64]$SkipAddress-([Int64]$RemoteBase+[Int64]$nativeSkipDispOffset+4)
if($nativeDisp64 -lt [Int32]::MinValue -or $nativeDisp64 -gt [Int32]::MaxValue){
throw 'native PSSM skip target is outside rel32 range'
}
[byte[]]$nativeDisp=[BitConverter]::GetBytes([Int32]$nativeDisp64)
[Array]::Copy($nativeDisp,0,$result,$nativeSkipDispOffset,4)
return ,$result
}
function New-ShadowClearDispatcher {
param([UInt64]$RemoteBase,[UInt64]$ContinueAddress,[int]$Divisor)
if($Divisor -lt 2 -or $Divisor -gt 5){throw "shadow divisor outside selective range 2..5: $Divisor"}
$code=New-Object System.Collections.Generic.List[byte]
[UInt64]$gateCounter=$RemoteBase+[UInt64]0x300
[UInt64]$fullFlag=$RemoteBase+[UInt64]0x304
[UInt64]$totalCounter=$RemoteBase+[UInt64]0x308
[UInt64]$fullCounter=$RemoteBase+[UInt64]0x30C
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $totalCounter
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xFF,0x03))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $gateCounter
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xFF,0x03))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0x83,0x3B,[byte]$Divisor))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x0F,0x82))
[int]$skipDispOffset=$code.Count
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0,0,0,0))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xC7,0x03,0x00,0x00,0x00,0x00))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $fullFlag
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xC6,0x03,0x01))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $fullCounter
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xFF,0x03))
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0xFF,0x90,0xB0,0x00,0x00,0x00))
Add-CodeBytes -Code $code -Bytes (New-AbsJumpBytes -TargetAddress $ContinueAddress -Register 'r11')
[int]$skipOffset=$code.Count
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x49,0xBB))
Add-CodeUInt64 -Code $code -Value $fullFlag
Add-CodeBytes -Code $code -Bytes ([byte[]]@(0x41,0xC6,0x03,0x00))
Add-CodeBytes -Code $code -Bytes (New-AbsJumpBytes -TargetAddress $ContinueAddress -Register 'r11')
[byte[]]$result=$code.ToArray()
Set-RelativeInt32 -Code $result -DisplacementOffset $skipDispOffset -TargetOffset $skipOffset
return ,$result
}
function New-NearJumpPatch {
param([UInt64]$PatchAddress,[UInt64]$StubAddress,[int]$PatchLength)
[Int64]$relative64=[Int64]$StubAddress-([Int64]$PatchAddress+5)
if($relative64 -lt [Int32]::MinValue -or $relative64 -gt [Int32]::MaxValue){
throw 'dispatcher is outside rel32 jump range'
}
[byte[]]$patch=New-Object byte[] $PatchLength
$patch[0]=0xE9
[byte[]]$disp=[BitConverter]::GetBytes([Int32]$relative64)
[Array]::Copy($disp,0,$patch,1,4)
for($i=5;$i -lt $PatchLength;$i++){$patch[$i]=0x90}
return ,$patch
}
function Reset-ShadowHookState {
$script:ShadowHandle=[IntPtr]::Zero
$script:ShadowRemotePage=[IntPtr]::Zero
[UInt64]$script:ShadowRemoteBase=0
[UInt64]$script:ShadowLoopPatchAddress=0
[UInt64]$script:ShadowClearPatchAddress=0
$script:ShadowGamePid=0
$script:ShadowHookActive=$false
$script:ShadowAvailable=$false
$script:ShadowBuildValid=$false
$script:ShadowDispatcherBytes=0
$script:ShadowActiveDivisor=0
[UInt32]$script:ShadowTotalCalls=0
[UInt32]$script:ShadowFullCalls=0
[byte[]]$script:ShadowInstalledLoopPatch=@()
[byte[]]$script:ShadowInstalledClearPatch=@()
[byte[]]$script:ShadowNativeLoop=@()
[byte[]]$script:ShadowNativeClear=@()
}
function Restore-ShadowHook {
param([string]$Reason='disabled')
if(-not $script:ShadowHookActive){
if($script:ShadowHandle -ne [IntPtr]::Zero){
if($script:ShadowRemotePage -ne [IntPtr]::Zero){
try{[void][BeamNGMirrorRateTest039]::VirtualFreeEx(
$script:ShadowHandle,$script:ShadowRemotePage,[UIntPtr]::Zero,[UInt32]0x8000)}catch{}
}
[void][BeamNGMirrorRateTest039]::CloseHandle($script:ShadowHandle)
}
Reset-ShadowHookState
$script:ShadowLastAction=$Reason
return $true
}
$alive=($script:ShadowGamePid -ne 0 -and
$null -ne (Get-Process -Id $script:ShadowGamePid -ErrorAction SilentlyContinue))
if(-not $alive){
Reset-ShadowHookState
$script:ShadowLastAction='game-exited'
$script:ShadowLastError='none'
return $true
}
try{
[byte[]]$nativeLoop=$script:ShadowNativeLoop
[byte[]]$nativeClear=$script:ShadowNativeClear
if($nativeLoop.Length -ne $ShadowLoopPatchLength -or
$nativeClear.Length -ne $ShadowClearPatchLength){
throw 'resolved native shadow bytes are unavailable for restore'
}
[byte[]]$curLoop=Read-RemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowLoopPatchAddress -Count $ShadowLoopPatchLength
[byte[]]$curClear=Read-RemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowClearPatchAddress -Count $ShadowClearPatchLength
if(-not (Test-ByteArraysEqual $curLoop $nativeLoop) -and
-not (Test-ByteArraysEqual $curLoop $script:ShadowInstalledLoopPatch)){
throw 'selective shadow loop restore conflict; another hook owns the site'
}
if(-not (Test-ByteArraysEqual $curClear $nativeClear) -and
-not (Test-ByteArraysEqual $curClear $script:ShadowInstalledClearPatch)){
throw 'selective shadow clear restore conflict; another hook owns the site'
}
if(Test-ByteArraysEqual $curLoop $script:ShadowInstalledLoopPatch){
Write-ProtectedRemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowLoopPatchAddress -Data $nativeLoop
}
if(Test-ByteArraysEqual $curClear $script:ShadowInstalledClearPatch){
Write-ProtectedRemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowClearPatchAddress -Data $nativeClear
}
[void][BeamNGMirrorRateTest039]::FlushInstructionCache(
$script:ShadowHandle,[IntPtr]([Int64]$script:ShadowLoopPatchAddress),[UIntPtr]([UInt64]$ShadowLoopPatchLength))
[void][BeamNGMirrorRateTest039]::FlushInstructionCache(
$script:ShadowHandle,[IntPtr]([Int64]$script:ShadowClearPatchAddress),[UIntPtr]([UInt64]$ShadowClearPatchLength))
[byte[]]$verifyLoop=Read-RemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowLoopPatchAddress -Count $ShadowLoopPatchLength
[byte[]]$verifyClear=Read-RemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowClearPatchAddress -Count $ShadowClearPatchLength
if(-not (Test-ByteArraysEqual $verifyLoop $nativeLoop) -or
-not (Test-ByteArraysEqual $verifyClear $nativeClear)){
throw 'selective shadow restore verification failed'
}
Start-Sleep -Milliseconds 100
if($script:ShadowRemotePage -ne [IntPtr]::Zero){
[void][BeamNGMirrorRateTest039]::VirtualFreeEx(
$script:ShadowHandle,$script:ShadowRemotePage,[UIntPtr]::Zero,[UInt32]0x8000)
}
[void][BeamNGMirrorRateTest039]::CloseHandle($script:ShadowHandle)
Reset-ShadowHookState
$script:ShadowLastError='none'
$script:ShadowLastAction=$Reason
return $true
}catch{
$script:ShadowLastError="shadow restore error: $($_.Exception.Message); exit BeamNG before continuing"
$script:ShadowLastAction='restore-error'
return $false
}
}
function Install-ShadowHook {
param([int]$Divisor)
if($Divisor -lt 2){$Divisor=2}
if($Divisor -gt 5){$Divisor=5}
if($script:ShadowHookActive){
if($script:ShadowActiveDivisor -eq $Divisor){return $true}
if(-not (Restore-ShadowHook -Reason 'shadow-rate-changed')){return $false}
}
[IntPtr]$handle=[IntPtr]::Zero
[IntPtr]$remotePage=[IntPtr]::Zero
[UInt64]$remoteBase=0
[UInt64]$loopPatchAddress=0
[UInt64]$clearPatchAddress=0
[byte[]]$installedLoop=@()
[byte[]]$installedClear=@()
[byte[]]$nativeLoop=@()
[byte[]]$nativeClear=@()
try{
$selection=Get-BeamNGSelection -RequestedProcessId 0
$gameProcess=$selection.Process
$mainModule=$selection.MainModule
[UInt64]$moduleBase=[UInt64]$mainModule.BaseAddress.ToInt64()
$fileInfo=Get-Item -LiteralPath $mainModule.FileName
# Version-flexible mode: executable size is informational only; local native validation is authoritative.
$PROCESS_VM_OPERATION=[UInt32]0x0008
$PROCESS_VM_READ=[UInt32]0x0010
$PROCESS_VM_WRITE=[UInt32]0x0020
$PROCESS_QUERY_INFORMATION=[UInt32]0x0400
$access=$PROCESS_VM_OPERATION -bor $PROCESS_VM_READ -bor $PROCESS_VM_WRITE -bor $PROCESS_QUERY_INFORMATION
$handle=[BeamNGMirrorRateTest039]::OpenProcess($access,$false,$gameProcess.Id)
if($handle -eq [IntPtr]::Zero){throw "OpenProcess failed with Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"}
$scan=Get-PeScanContext -ExePath $mainModule.FileName
$shadowLayout=Resolve-ShadowScanLayout -Context $scan

$loopPatchAddress=$moduleBase+[UInt64]$shadowLayout.LoopRva
$clearPatchAddress=$moduleBase+[UInt64]$shadowLayout.ClearCallRva
[UInt64]$clearContextAddress=$moduleBase+[UInt64]$shadowLayout.ClearContextRva
$nativeLoop=[byte[]]$shadowLayout.NativeLoop
$nativeClear=[byte[]]$shadowLayout.NativeClear
[byte[]]$nativeClearContext=Read-PeBytesAtRva `
-Context $scan -Rva ([UInt64]$shadowLayout.ClearContextRva) -Count 13

[byte[]]$liveLoop=Read-RemoteBytes -Handle $handle -Address $loopPatchAddress -Count $nativeLoop.Length
[byte[]]$liveClearContext=Read-RemoteBytes -Handle $handle -Address $clearContextAddress -Count $nativeClearContext.Length

if(-not (Test-ByteArraysEqual $liveLoop $nativeLoop)){throw 'pattern-resolved PSSM loop site is not native; stop any standalone selective-shadow hook first'}
if(-not (Test-ByteArraysEqual $liveClearContext $nativeClearContext)){throw 'pattern-resolved PSSM atlas-clear site is not native; stop any standalone selective-shadow hook first'}
$remotePage=Allocate-NearShadowTarget -Handle $handle -TargetAddress $loopPatchAddress
$remoteBase=[UInt64]$remotePage.ToInt64()
[UInt64]$clearStubAddress=$remoteBase+[UInt64]0x200
[byte[]]$loopStub=New-ShadowLoopDispatcher `
-RemoteBase $remoteBase `
-ContinueAddress ($moduleBase+[UInt64]$shadowLayout.ContinueRva) `
-SkipAddress ($moduleBase+[UInt64]$shadowLayout.SkipRva)
[byte[]]$clearStub=New-ShadowClearDispatcher `
-RemoteBase $remoteBase `
-ContinueAddress ($moduleBase+[UInt64]$shadowLayout.ClearContinueRva) `
-Divisor $Divisor
if($loopStub.Length -ge 0x200){throw "loop dispatcher too large: $($loopStub.Length)"}
if($clearStub.Length -ge 0x100){throw "clear dispatcher too large: $($clearStub.Length)"}
Write-RemoteBytes -Handle $handle -Address $remoteBase -Data $loopStub
Write-RemoteBytes -Handle $handle -Address $clearStubAddress -Data $clearStub
[byte[]]$state=New-Object byte[] 16
[Array]::Copy([BitConverter]::GetBytes([UInt32]($Divisor-1)),0,$state,0,4)
$state[4]=1
Write-RemoteBytes -Handle $handle -Address ($remoteBase+0x300) -Data $state
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($handle,$remotePage,[UIntPtr]([UInt64]0x300))
$installedLoop=New-NearJumpPatch -PatchAddress $loopPatchAddress -StubAddress $remoteBase -PatchLength $ShadowLoopPatchLength
$installedClear=New-NearJumpPatch -PatchAddress $clearPatchAddress -StubAddress $clearStubAddress -PatchLength $ShadowClearPatchLength
Write-ProtectedRemoteBytes -Handle $handle -Address $loopPatchAddress -Data $installedLoop
[void][BeamNGMirrorRateTest039]::FlushInstructionCache(
$handle,[IntPtr]([Int64]$loopPatchAddress),[UIntPtr]([UInt64]$installedLoop.Length))
Write-ProtectedRemoteBytes -Handle $handle -Address $clearPatchAddress -Data $installedClear
[void][BeamNGMirrorRateTest039]::FlushInstructionCache(
$handle,[IntPtr]([Int64]$clearPatchAddress),[UIntPtr]([UInt64]$installedClear.Length))
[byte[]]$verifyLoop=Read-RemoteBytes -Handle $handle -Address $loopPatchAddress -Count $installedLoop.Length
[byte[]]$verifyClear=Read-RemoteBytes -Handle $handle -Address $clearPatchAddress -Count $installedClear.Length
if(-not (Test-ByteArraysEqual $verifyLoop $installedLoop) -or
-not (Test-ByteArraysEqual $verifyClear $installedClear)){throw 'selective shadow hook verification failed'}
$script:ShadowHandle=$handle
$script:ShadowRemotePage=$remotePage
$script:ShadowRemoteBase=$remoteBase
$script:ShadowLoopPatchAddress=$loopPatchAddress
$script:ShadowClearPatchAddress=$clearPatchAddress
$script:ShadowGamePid=[int]$gameProcess.Id
$script:ShadowHookActive=$true
$script:ShadowAvailable=$true
$script:ShadowBuildValid=$true
$script:ShadowDispatcherBytes=$loopStub.Length+$clearStub.Length
$script:ShadowActiveDivisor=$Divisor
$script:ShadowInstalledLoopPatch=$installedLoop
$script:ShadowInstalledClearPatch=$installedClear
$script:ShadowNativeLoop=$nativeLoop
$script:ShadowNativeClear=$nativeClear
[UInt32]$script:ShadowTotalCalls=0
[UInt32]$script:ShadowFullCalls=0
$script:ShadowLastError='none'
$script:ShadowLastAction='installed'
Write-Host ("[BeamOpt] SELECTIVE SHADOW ACTIVE 1/{0} | VehicleShadowTex full-rate | PID {1}" -f $Divisor,$script:ShadowGamePid)
return $true
}catch{
$err=$_.Exception.Message
if($handle -ne [IntPtr]::Zero){
try{
# nativeLoop/nativeClear were captured from the pattern-resolved executable image.
if($loopPatchAddress -ne 0 -and $installedLoop.Length -eq $ShadowLoopPatchLength){
[byte[]]$cur=Read-RemoteBytes -Handle $handle -Address $loopPatchAddress -Count $ShadowLoopPatchLength
if(Test-ByteArraysEqual $cur $installedLoop){Write-ProtectedRemoteBytes -Handle $handle -Address $loopPatchAddress -Data $nativeLoop}
}
if($clearPatchAddress -ne 0 -and $installedClear.Length -eq $ShadowClearPatchLength){
[byte[]]$cur=Read-RemoteBytes -Handle $handle -Address $clearPatchAddress -Count $ShadowClearPatchLength
if(Test-ByteArraysEqual $cur $installedClear){Write-ProtectedRemoteBytes -Handle $handle -Address $clearPatchAddress -Data $nativeClear}
}
}catch{}
if($remotePage -ne [IntPtr]::Zero){
try{[void][BeamNGMirrorRateTest039]::VirtualFreeEx($handle,$remotePage,[UIntPtr]::Zero,[UInt32]0x8000)}catch{}
}
[void][BeamNGMirrorRateTest039]::CloseHandle($handle)
}
$script:ShadowLastError=$err
$script:ShadowLastAction='install-failed'
$script:ShadowAvailable=$false
$script:ShadowBuildValid=$false
Write-Warning "[BeamOpt] selective shadow: $err"
return $false
}
}
function Validate-ShadowHook {
if(-not $script:ShadowHookActive){return $false}
if($script:ShadowGamePid -eq 0 -or
$null -eq (Get-Process -Id $script:ShadowGamePid -ErrorAction SilentlyContinue)){
Reset-ShadowHookState
$script:ShadowLastError='none'
$script:ShadowLastAction='game-exited'
return $false
}
try{
[byte[]]$loop=Read-RemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowLoopPatchAddress -Count $ShadowLoopPatchLength
[byte[]]$clear=Read-RemoteBytes -Handle $script:ShadowHandle -Address $script:ShadowClearPatchAddress -Count $ShadowClearPatchLength
if(-not (Test-ByteArraysEqual $loop $script:ShadowInstalledLoopPatch) -or
-not (Test-ByteArraysEqual $clear $script:ShadowInstalledClearPatch)){
$script:ShadowLastError='selective shadow hook disappeared or was replaced'
$script:ShadowLastAction='hook-lost'
$script:ShadowHookActive=$false
return $false
}
Update-ShadowCounters
return $true
}catch{
$script:ShadowLastError="shadow validation failed: $($_.Exception.Message)"
$script:ShadowLastAction='validation-failed'
Restore-ShadowHook -Reason 'validation-failed' | Out-Null
return $false
}
}
# ---------------- PSSM 6.0 writer-freeze ----------------
function Reset-Pssm6State {
$script:Pssm6Handle=[IntPtr]::Zero
$script:Pssm6GamePid=0
[UInt64]$script:Pssm6WriterAddress=0
[UInt64]$script:Pssm6ValueAddress=0
[byte[]]$script:Pssm6RestoreValue=@()
[byte[]]$script:Pssm6WriterNative=@()
$script:Pssm6Active=$false
$script:Pssm6Available=$false
$script:Pssm6BuildValid=$false
}
function Restore-Pssm6Patch {
param([string]$Reason='disabled')
if(-not $script:Pssm6Active){
if($script:Pssm6Handle -ne [IntPtr]::Zero){[void][BeamNGMirrorRateTest039]::CloseHandle($script:Pssm6Handle)}
Reset-Pssm6State
$script:Pssm6LastAction=$Reason
return $true
}
$alive=($script:Pssm6GamePid -ne 0 -and $null -ne (Get-Process -Id $script:Pssm6GamePid -ErrorAction SilentlyContinue))
if(-not $alive){
Reset-Pssm6State;$script:Pssm6LastError='none';$script:Pssm6LastAction='game-exited';return $true
}
try{
[byte[]]$writerNative=$script:Pssm6WriterNative
if($writerNative.Length -ne 8){throw 'resolved PSSM writer bytes are unavailable for restore'}
[byte[]]$writerNops=[byte[]]@(0x90,0x90,0x90,0x90,0x90,0x90,0x90,0x90)
[byte[]]$curWriter=Read-RemoteBytes -Handle $script:Pssm6Handle -Address $script:Pssm6WriterAddress -Count 8
if(-not (Test-ByteArraysEqual $curWriter $writerNops) -and -not (Test-ByteArraysEqual $curWriter $writerNative)){throw 'PSSM 6.0 writer restore conflict'}
if(Test-ByteArraysEqual $curWriter $writerNops){
if($script:Pssm6RestoreValue.Length -eq 4){
Write-RemoteBytes -Handle $script:Pssm6Handle -Address $script:Pssm6ValueAddress -Data $script:Pssm6RestoreValue
}
Write-ProtectedRemoteBytes -Handle $script:Pssm6Handle -Address $script:Pssm6WriterAddress -Data $writerNative
[void][BeamNGMirrorRateTest039]::FlushInstructionCache(
$script:Pssm6Handle,[IntPtr]([Int64]$script:Pssm6WriterAddress),[UIntPtr]([UInt64]8))
}
[byte[]]$verify=Read-RemoteBytes -Handle $script:Pssm6Handle -Address $script:Pssm6WriterAddress -Count 8
if(-not (Test-ByteArraysEqual $verify $writerNative)){throw 'PSSM 6.0 writer restore verification failed'}
[void][BeamNGMirrorRateTest039]::CloseHandle($script:Pssm6Handle)
Reset-Pssm6State
$script:Pssm6LastError='none';$script:Pssm6LastAction=$Reason
return $true
}catch{
$script:Pssm6LastError="PSSM 6.0 restore error: $($_.Exception.Message); exit BeamNG before continuing"
$script:Pssm6LastAction='restore-error';return $false
}
}
function Install-Pssm6Patch {
if($script:Pssm6Active){return $true}
[IntPtr]$handle=[IntPtr]::Zero
[UInt64]$writerAddress=0
[UInt64]$valueAddress=0
[byte[]]$restoreValue=@()
[byte[]]$writerNative=@()
try{
$selection=Get-BeamNGSelection -RequestedProcessId 0
$game=$selection.Process;$module=$selection.MainModule
$file=Get-Item -LiteralPath $module.FileName
# Version-flexible mode: executable size is informational only; local native validation is authoritative.
[UInt64]$base=[UInt64]$module.BaseAddress.ToInt64()
$access=[UInt32]0x0008 -bor [UInt32]0x0010 -bor [UInt32]0x0020 -bor [UInt32]0x0400
$handle=[BeamNGMirrorRateTest039]::OpenProcess($access,$false,$game.Id)
if($handle -eq [IntPtr]::Zero){throw 'OpenProcess failed'}
$scan=Get-PeScanContext -ExePath $module.FileName
$pssmLayout=Resolve-Pssm6ScanLayout -Context $scan

$writerAddress=$base+[UInt64]$pssmLayout.WriterRva
$valueAddress=$base+[UInt64]$pssmLayout.ValueRva
[UInt64]$sigAddress=$base+[UInt64]$pssmLayout.SplitRva
$writerNative=[byte[]]$pssmLayout.NativeWriter
[byte[]]$splitNative=[byte[]]$pssmLayout.NativeSplit

[byte[]]$liveWriter=Read-RemoteBytes -Handle $handle -Address $writerAddress -Count $writerNative.Length
[byte[]]$liveSig=Read-RemoteBytes -Handle $handle -Address $sigAddress -Count $splitNative.Length

if(-not (Test-ByteArraysEqual $liveWriter $writerNative)){throw 'pattern-resolved PSSM 6.0 writer is not native; stop any standalone writer-freeze test first'}
if(-not (Test-ByteArraysEqual $liveSig $splitNative)){throw 'pattern-resolved PSSM split-math bytes changed in memory'}
$restoreValue=Read-RemoteBytes -Handle $handle -Address $valueAddress -Count 4
[single]$current=[BitConverter]::ToSingle($restoreValue,0)
if([single]::IsNaN($current) -or [single]::IsInfinity($current) -or $current -lt 0.20 -or $current -ge 5.0){
throw "unexpected native PSSM runtime value $current"
}
[byte[]]$nops=[byte[]]@(0x90,0x90,0x90,0x90,0x90,0x90,0x90,0x90)
Write-ProtectedRemoteBytes -Handle $handle -Address $writerAddress -Data $nops
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($handle,[IntPtr]([Int64]$writerAddress),[UIntPtr]([UInt64]8))
[byte[]]$six=[BitConverter]::GetBytes([single]$Pssm6TestValue)
Write-RemoteBytes -Handle $handle -Address $valueAddress -Data $six
Start-Sleep -Milliseconds 100
[byte[]]$verifyWriter=Read-RemoteBytes -Handle $handle -Address $writerAddress -Count 8
[byte[]]$verifyValue=Read-RemoteBytes -Handle $handle -Address $valueAddress -Count 4
if(-not (Test-ByteArraysEqual $verifyWriter $nops) -or -not (Test-ByteArraysEqual $verifyValue $six)){throw 'PSSM 6.0 patch verification failed'}
$script:Pssm6Handle=$handle;$script:Pssm6GamePid=[int]$game.Id
$script:Pssm6WriterAddress=$writerAddress;$script:Pssm6ValueAddress=$valueAddress
$script:Pssm6RestoreValue=$restoreValue
$script:Pssm6WriterNative=$writerNative
$script:Pssm6Active=$true;$script:Pssm6Available=$true;$script:Pssm6BuildValid=$true
$script:Pssm6LastError='none';$script:Pssm6LastAction="active 6.0 (captured $current)"
Write-Host ("[BeamOpt] PSSM 6.0 ACTIVE | captured native {0:R}" -f $current)
return $true
}catch{
$err=$_.Exception.Message
if($handle -ne [IntPtr]::Zero){
try{
if($writerNative.Length -ne 8){$writerNative=@()}
[byte[]]$nops=[byte[]]@(0x90,0x90,0x90,0x90,0x90,0x90,0x90,0x90)
if($writerAddress -ne 0){
[byte[]]$cur=Read-RemoteBytes -Handle $handle -Address $writerAddress -Count 8
if(Test-ByteArraysEqual $cur $nops){
if($valueAddress -ne 0 -and $restoreValue.Length -eq 4){Write-RemoteBytes -Handle $handle -Address $valueAddress -Data $restoreValue}
Write-ProtectedRemoteBytes -Handle $handle -Address $writerAddress -Data $writerNative
}
}
}catch{}
[void][BeamNGMirrorRateTest039]::CloseHandle($handle)
}
$script:Pssm6LastError=$err;$script:Pssm6LastAction='install-failed'
$script:Pssm6Available=$false;$script:Pssm6BuildValid=$false
Write-Warning "[BeamOpt] PSSM 6.0: $err";return $false
}
}
function Validate-Pssm6Patch {
if(-not $script:Pssm6Active){return $false}
if($script:Pssm6GamePid -eq 0 -or $null -eq (Get-Process -Id $script:Pssm6GamePid -ErrorAction SilentlyContinue)){Reset-Pssm6State;return $false}
try{
[byte[]]$nops=[byte[]]@(0x90,0x90,0x90,0x90,0x90,0x90,0x90,0x90)
[byte[]]$six=[BitConverter]::GetBytes([single]$Pssm6TestValue)
[byte[]]$writer=Read-RemoteBytes -Handle $script:Pssm6Handle -Address $script:Pssm6WriterAddress -Count 8
[byte[]]$value=Read-RemoteBytes -Handle $script:Pssm6Handle -Address $script:Pssm6ValueAddress -Count 4
if(-not (Test-ByteArraysEqual $writer $nops) -or -not (Test-ByteArraysEqual $value $six)){throw 'PSSM 6.0 patch changed'}
return $true
}catch{
$script:Pssm6LastError=$_.Exception.Message;$script:Pssm6LastAction='validation-failed'
Restore-Pssm6Patch -Reason 'validation-failed' | Out-Null
return $false
}
}
# ---------------- world caster-mask 0x100 ----------------
function Reset-CasterState {
$script:CasterHandle=[IntPtr]::Zero;$script:CasterGamePid=0
[UInt64]$script:CasterInstructionAddress=0;[UInt64]$script:CasterImmediateAddress=0
$script:CasterActive=$false;$script:CasterAvailable=$false;$script:CasterBuildValid=$false
}
function Restore-CasterPatch {
param([string]$Reason='disabled')
if(-not $script:CasterActive){
if($script:CasterHandle -ne [IntPtr]::Zero){[void][BeamNGMirrorRateTest039]::CloseHandle($script:CasterHandle)}
Reset-CasterState;$script:CasterLastAction=$Reason;return $true
}
$alive=($script:CasterGamePid -ne 0 -and $null -ne (Get-Process -Id $script:CasterGamePid -ErrorAction SilentlyContinue))
if(-not $alive){Reset-CasterState;$script:CasterLastError='none';$script:CasterLastAction='game-exited';return $true}
try{
[byte[]]$native=Convert-HexStringToBytes $CasterNativeImmediateHex
[byte[]]$fast=Convert-HexStringToBytes $CasterFastImmediateHex
[byte[]]$cur=Read-RemoteBytes -Handle $script:CasterHandle -Address $script:CasterImmediateAddress -Count 4
if(-not (Test-ByteArraysEqual $cur $native) -and -not (Test-ByteArraysEqual $cur $fast)){throw 'caster-mask restore conflict'}
if(Test-ByteArraysEqual $cur $fast){
Write-ProtectedRemoteBytes -Handle $script:CasterHandle -Address $script:CasterImmediateAddress -Data $native
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($script:CasterHandle,[IntPtr]([Int64]$script:CasterImmediateAddress),[UIntPtr]([UInt64]4))
}
[byte[]]$verify=Read-RemoteBytes -Handle $script:CasterHandle -Address $script:CasterImmediateAddress -Count 4
if(-not (Test-ByteArraysEqual $verify $native)){throw 'caster-mask restore verification failed'}
[void][BeamNGMirrorRateTest039]::CloseHandle($script:CasterHandle)
Reset-CasterState;$script:CasterLastError='none';$script:CasterLastAction=$Reason;return $true
}catch{
$script:CasterLastError="caster restore error: $($_.Exception.Message); exit BeamNG before continuing"
$script:CasterLastAction='restore-error';return $false
}
}
function Install-CasterPatch {
if($script:CasterActive){return $true}
[IntPtr]$handle=[IntPtr]::Zero
[UInt64]$instAddress=0;[UInt64]$immAddress=0
try{
$selection=Get-BeamNGSelection -RequestedProcessId 0
$game=$selection.Process;$module=$selection.MainModule
$file=Get-Item -LiteralPath $module.FileName
# Version-flexible mode: executable size is informational only; local native validation is authoritative.
[UInt64]$base=[UInt64]$module.BaseAddress.ToInt64()
$access=[UInt32]0x0008 -bor [UInt32]0x0010 -bor [UInt32]0x0020 -bor [UInt32]0x0400
$handle=[BeamNGMirrorRateTest039]::OpenProcess($access,$false,$game.Id)
if($handle -eq [IntPtr]::Zero){throw 'OpenProcess failed'}
$scan=Get-PeScanContext -ExePath $module.FileName
$casterLayout=Resolve-CasterScanLayout -Context $scan
$instAddress=$base+[UInt64]$casterLayout.InstructionRva
$immAddress=$base+[UInt64]$casterLayout.ImmediateRva
[byte[]]$context=[byte[]]$casterLayout.NativeContext
[byte[]]$live=Read-RemoteBytes -Handle $handle -Address $instAddress -Count $context.Length
if(-not (Test-ByteArraysEqual $live $context)){throw 'pattern-resolved caster-mask instruction is not native; stop any standalone caster-mask test first'}
[byte[]]$fast=Convert-HexStringToBytes $CasterFastImmediateHex
Write-ProtectedRemoteBytes -Handle $handle -Address $immAddress -Data $fast
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($handle,[IntPtr]([Int64]$immAddress),[UIntPtr]([UInt64]4))
[byte[]]$verify=Read-RemoteBytes -Handle $handle -Address $immAddress -Count 4
if(-not (Test-ByteArraysEqual $verify $fast)){throw 'caster-mask patch verification failed'}
$script:CasterHandle=$handle;$script:CasterGamePid=[int]$game.Id
$script:CasterInstructionAddress=$instAddress;$script:CasterImmediateAddress=$immAddress
$script:CasterActive=$true;$script:CasterAvailable=$true;$script:CasterBuildValid=$true
$script:CasterLastError='none';$script:CasterLastAction='active 0x100'
Write-Host '[BeamOpt] WORLD CASTER MASK ACTIVE 0x100';return $true
}catch{
$err=$_.Exception.Message
if($handle -ne [IntPtr]::Zero){
try{
if($immAddress -ne 0){
[byte[]]$fast=Convert-HexStringToBytes $CasterFastImmediateHex
[byte[]]$native=Convert-HexStringToBytes $CasterNativeImmediateHex
[byte[]]$cur=Read-RemoteBytes -Handle $handle -Address $immAddress -Count 4
if(Test-ByteArraysEqual $cur $fast){Write-ProtectedRemoteBytes -Handle $handle -Address $immAddress -Data $native}
}
}catch{}
[void][BeamNGMirrorRateTest039]::CloseHandle($handle)
}
$script:CasterLastError=$err;$script:CasterLastAction='install-failed'
$script:CasterAvailable=$false;$script:CasterBuildValid=$false
Write-Warning "[BeamOpt] caster mask: $err";return $false
}
}
function Validate-CasterPatch {
if(-not $script:CasterActive){return $false}
if($script:CasterGamePid -eq 0 -or $null -eq (Get-Process -Id $script:CasterGamePid -ErrorAction SilentlyContinue)){Reset-CasterState;return $false}
try{
[byte[]]$fast=Convert-HexStringToBytes $CasterFastImmediateHex
[byte[]]$cur=Read-RemoteBytes -Handle $script:CasterHandle -Address $script:CasterImmediateAddress -Count 4
if(-not (Test-ByteArraysEqual $cur $fast)){throw 'caster-mask patch changed'}
return $true
}catch{
$script:CasterLastError=$_.Exception.Message;$script:CasterLastAction='validation-failed'
Restore-CasterPatch -Reason 'validation-failed' | Out-Null;return $false
}
}
# ---------------- optional 3-split PSSM ----------------
function Reset-Split3State {
$script:Split3Handle=[IntPtr]::Zero;$script:Split3GamePid=0
[UInt64]$script:Split3CompareAddress=0;[UInt64]$script:Split3SetterAddress=0
$script:Split3Active=$false;$script:Split3Available=$false;$script:Split3BuildValid=$false
}
function Restore-Split3Patch {
param([string]$Reason='disabled')
if(-not $script:Split3Active){
if($script:Split3Handle -ne [IntPtr]::Zero){[void][BeamNGMirrorRateTest039]::CloseHandle($script:Split3Handle)}
Reset-Split3State;$script:Split3LastAction=$Reason;return $true
}
$alive=($script:Split3GamePid -ne 0 -and $null -ne (Get-Process -Id $script:Split3GamePid -ErrorAction SilentlyContinue))
if(-not $alive){Reset-Split3State;$script:Split3LastError='none';$script:Split3LastAction='game-exited';return $true}
try{
[byte[]]$curCmp=Read-RemoteBytes -Handle $script:Split3Handle -Address $script:Split3CompareAddress -Count 1
[byte[]]$curSet=Read-RemoteBytes -Handle $script:Split3Handle -Address $script:Split3SetterAddress -Count 1
if(($curCmp[0] -ne 3 -and $curCmp[0] -ne 4) -or ($curSet[0] -ne 3 -and $curSet[0] -ne 4)){throw '3-split restore conflict'}
Write-ProtectedRemoteBytes -Handle $script:Split3Handle -Address $script:Split3CompareAddress -Data ([byte[]]@(4))
Write-ProtectedRemoteBytes -Handle $script:Split3Handle -Address $script:Split3SetterAddress -Data ([byte[]]@(4))
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($script:Split3Handle,[IntPtr]([Int64]$script:Split3CompareAddress),[UIntPtr]([UInt64]1))
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($script:Split3Handle,[IntPtr]([Int64]$script:Split3SetterAddress),[UIntPtr]([UInt64]1))
[void][BeamNGMirrorRateTest039]::CloseHandle($script:Split3Handle)
Reset-Split3State;$script:Split3LastError='none';$script:Split3LastAction=$Reason;return $true
}catch{
$script:Split3LastError="3-split restore error: $($_.Exception.Message); exit BeamNG before continuing"
$script:Split3LastAction='restore-error';return $false
}
}
function Install-Split3Patch {
if($script:Split3Active){return $true}
[IntPtr]$handle=[IntPtr]::Zero
[UInt64]$cmpAddress=0;[UInt64]$setAddress=0
try{
$selection=Get-BeamNGSelection -RequestedProcessId 0
$game=$selection.Process;$module=$selection.MainModule
$file=Get-Item -LiteralPath $module.FileName
# Version-flexible mode: executable size is informational only; local native validation is authoritative.
[UInt64]$base=[UInt64]$module.BaseAddress.ToInt64()
$access=[UInt32]0x0008 -bor [UInt32]0x0010 -bor [UInt32]0x0020 -bor [UInt32]0x0400
$handle=[BeamNGMirrorRateTest039]::OpenProcess($access,$false,$game.Id)
if($handle -eq [IntPtr]::Zero){throw 'OpenProcess failed'}
$scan=Get-PeScanContext -ExePath $module.FileName
$splitLayout=Resolve-Split3ScanLayout -Context $scan
[UInt64]$cmpInst=$base+[UInt64]$splitLayout.CompareInstructionRva
[UInt64]$setInst=$base+[UInt64]$splitLayout.SetterInstructionRva
$cmpAddress=$base+[UInt64]$splitLayout.CompareImmediateRva
$setAddress=$base+[UInt64]$splitLayout.SetterImmediateRva
[byte[]]$cmpNative=[byte[]]$splitLayout.NativeCompare
[byte[]]$setNative=[byte[]]$splitLayout.NativeSetter
[byte[]]$liveCmp=Read-RemoteBytes -Handle $handle -Address $cmpInst -Count $cmpNative.Length
[byte[]]$liveSet=Read-RemoteBytes -Handle $handle -Address $setInst -Count $setNative.Length
if(-not (Test-ByteArraysEqual $liveCmp $cmpNative) -or -not (Test-ByteArraysEqual $liveSet $setNative)){
throw 'PSSM split-count instructions are not native; stop any standalone split-count test first'
}
Write-ProtectedRemoteBytes -Handle $handle -Address $cmpAddress -Data ([byte[]]@(3))
Write-ProtectedRemoteBytes -Handle $handle -Address $setAddress -Data ([byte[]]@(3))
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($handle,[IntPtr]([Int64]$cmpAddress),[UIntPtr]([UInt64]1))
[void][BeamNGMirrorRateTest039]::FlushInstructionCache($handle,[IntPtr]([Int64]$setAddress),[UIntPtr]([UInt64]1))
$script:Split3Handle=$handle;$script:Split3GamePid=[int]$game.Id
$script:Split3CompareAddress=$cmpAddress;$script:Split3SetterAddress=$setAddress
$script:Split3Active=$true;$script:Split3Available=$true;$script:Split3BuildValid=$true
$script:Split3LastError='none';$script:Split3LastAction='active 3 splits'
Write-Host '[BeamOpt] PSSM 3-SPLIT ACTIVE';return $true
}catch{
$err=$_.Exception.Message
if($handle -ne [IntPtr]::Zero){
try{
if($cmpAddress -ne 0){
[byte[]]$c=Read-RemoteBytes -Handle $handle -Address $cmpAddress -Count 1
if($c[0] -eq 3){Write-ProtectedRemoteBytes -Handle $handle -Address $cmpAddress -Data ([byte[]]@(4))}
}
if($setAddress -ne 0){
[byte[]]$s=Read-RemoteBytes -Handle $handle -Address $setAddress -Count 1
if($s[0] -eq 3){Write-ProtectedRemoteBytes -Handle $handle -Address $setAddress -Data ([byte[]]@(4))}
}
}catch{}
[void][BeamNGMirrorRateTest039]::CloseHandle($handle)
}
$script:Split3LastError=$err;$script:Split3LastAction='install-failed'
$script:Split3Available=$false;$script:Split3BuildValid=$false
Write-Warning "[BeamOpt] 3-split PSSM: $err";return $false
}
}
function Validate-Split3Patch {
if(-not $script:Split3Active){return $false}
if($script:Split3GamePid -eq 0 -or $null -eq (Get-Process -Id $script:Split3GamePid -ErrorAction SilentlyContinue)){Reset-Split3State;return $false}
try{
[byte[]]$c=Read-RemoteBytes -Handle $script:Split3Handle -Address $script:Split3CompareAddress -Count 1
[byte[]]$s=Read-RemoteBytes -Handle $script:Split3Handle -Address $script:Split3SetterAddress -Count 1
if($c[0] -ne 3 -or $s[0] -ne 3){throw '3-split patch changed'}
return $true
}catch{
$script:Split3LastError=$_.Exception.Message;$script:Split3LastAction='validation-failed'
Restore-Split3Patch -Reason 'validation-failed' | Out-Null;return $false
}
}
# ---------------- bridge runtime ----------------

$script:ControlPath = $null
$script:ControlPathAnnounced = $false
$script:NextControlDiscoveryUtc = [DateTime]::MinValue
$script:LastSearchRoots = @()
$script:LastWaitingPrintUtc = [DateTime]::MinValue
$script:SettingsDir = $null
$script:StatusPath = $null
$script:LastHeartbeat = [Int64]-1
$script:LastHeartbeatChangeUtc = [DateTime]::MinValue
$script:LastControlWriteUtc = [DateTime]::MinValue
$script:StatusSequence = [Int64]0

$script:LastError = 'waiting for BeamOpt control file'
$script:LastAction = 'waiting-control'
$script:Rebuilds = 0
Reset-HookState

$script:PlaneLastError = 'waiting for BeamOpt control file'
$script:PlaneLastAction = 'waiting-control'
$script:PlaneRebuilds = 0
Reset-PlaneHookState

$script:ShadowLastError = 'waiting for BeamOpt control file'
$script:ShadowLastAction = 'waiting-control'
$script:ShadowRebuilds = 0
Reset-ShadowHookState

$script:Pssm6LastError = 'waiting for BeamOpt control file'
$script:Pssm6LastAction = 'waiting-control'
Reset-Pssm6State

$script:CasterLastError = 'waiting for BeamOpt control file'
$script:CasterLastAction = 'waiting-control'
Reset-CasterState

$script:Split3LastError = 'waiting for BeamOpt control file'
$script:Split3LastAction = 'waiting-control'
Reset-Split3State

$script:NextCubeInstallUtc = [DateTime]::MinValue
$script:NextPlaneInstallUtc = [DateTime]::MinValue
$script:NextShadowInstallUtc = [DateTime]::MinValue
$script:NextPssm6InstallUtc = [DateTime]::MinValue
$script:NextCasterInstallUtc = [DateTime]::MinValue
$script:NextSplit3InstallUtc = [DateTime]::MinValue

Write-Host ''
Write-Host '============================================================'
Write-Host ' BeamOpt v3.9.2 Native Bridge'
Write-Host ' Pattern Scan + Reflectors + Selective Shadows + PSSM Speedups'
Write-Host '============================================================'
Write-Host 'One PowerShell process owns all native hooks.'
Write-Host 'Press Q at any time to restore ALL hooks and exit.'
Write-Host ''

$nextValidation = [DateTime]::UtcNow
$nextStatus = [DateTime]::UtcNow
$nextConsoleStatus = [DateTime]::UtcNow.AddSeconds(5)
$quit = $false
$control = $null

try {
    while (-not $quit) {
        try {
            if ([Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.Key -eq [ConsoleKey]::Q) { $quit = $true; break }
            }
        } catch { }

        $control = Read-Control

        if ($control) {
            if ($script:LastHeartbeat -ne $control.Heartbeat) {
                $script:LastHeartbeat = $control.Heartbeat
                $script:LastHeartbeatChangeUtc = [DateTime]::UtcNow
            }
            $script:LastControlWriteUtc = $control.LastWriteUtc

            $freshByFile = (([DateTime]::UtcNow - $control.LastWriteUtc).TotalSeconds -le $StaleControlSeconds)
            $freshByHeartbeat = (
                $script:LastHeartbeatChangeUtc -ne [DateTime]::MinValue -and
                (([DateTime]::UtcNow - $script:LastHeartbeatChangeUtc).TotalSeconds -le $StaleControlSeconds)
            )
            $fresh = ($freshByFile -or $freshByHeartbeat)

            if (-not $fresh) {
                if ($script:HookActive) { Restore-Hook -Reason 'control-stale' | Out-Null }
                if ($script:PlaneHookActive) { Restore-PlaneHook -Reason 'control-stale' | Out-Null }
                if ($script:ShadowHookActive) { Restore-ShadowHook -Reason 'control-stale' | Out-Null }
                if ($script:Split3Active) { Restore-Split3Patch -Reason 'control-stale' | Out-Null }
                if ($script:CasterActive) { Restore-CasterPatch -Reason 'control-stale' | Out-Null }
                if ($script:Pssm6Active) { Restore-Pssm6Patch -Reason 'control-stale' | Out-Null }
            }
            else {
                $script:MirrorAutoViewEnabled = $control.MirrorAutoViewEnabled
                $script:MirrorPreferenceDesired = $control.MirrorPreferenceDesired
                $script:MirrorCameraName = $control.MirrorCameraName
                $script:MirrorCameraInterior = $control.MirrorCameraInterior

                if ($null -eq $control.MirrorCameraInterior) {
                    $script:MirrorViewMode = 'unknown'
                }
                elseif ($control.MirrorCameraInterior -eq $true) {
                    $script:MirrorViewMode = 'interior'
                }
                else {
                    $script:MirrorViewMode = 'exterior'
                }

                # ---- combined CubeReflector hook: mirrors + vehicle dynamic ----
                $cubeWanted = ($control.MirrorDesired -or $control.DynamicDesired)

                if (-not $cubeWanted) {
                    if ($script:HookActive) {
                        Restore-Hook -Reason 'cube-native' | Out-Null
                        Write-Host '[BeamOpt] CUBE NATIVE'
                    }
                }
                else {
                    $configMismatch = (
                        -not $script:HookActive -or
                        $script:MirrorThrottleActive -ne $control.MirrorDesired -or
                        $script:DynamicThrottleActive -ne $control.DynamicDesired -or
                        ($control.MirrorDesired -and $script:ActiveMirrorDivisor -ne $control.MirrorDivisor) -or
                        ($control.DynamicDesired -and $script:ActiveDynamicDivisor -ne $control.DynamicDivisor)
                    )

                    if ($configMismatch -and [DateTime]::UtcNow -ge $script:NextCubeInstallUtc) {
                        $script:NextCubeInstallUtc = [DateTime]::UtcNow.AddMilliseconds(
                            $(if ($control.MirrorAutoViewEnabled -and $control.MirrorDesired) { 500 } else { 1000 }))
                        [void](Install-Hook `
                            -MirrorDesired $control.MirrorDesired `
                            -MirrorDivisor $control.MirrorDivisor `
                            -MirrorAutoViewEnabled $control.MirrorAutoViewEnabled `
                            -DynamicDesired $control.DynamicDesired `
                            -DynamicDivisor $control.DynamicDivisor)
                    }
                }

                # ---- PlaneReflectors ----
                if (-not $control.PlaneDesired) {
                    if ($script:PlaneHookActive) {
                        Restore-PlaneHook -Reason 'plane-native' | Out-Null
                        Write-Host '[BeamOpt] PLANE NATIVE'
                    }
                }
                else {
                    if (($script:PlaneHookActive -and $script:PlaneActiveDivisor -ne $control.PlaneDivisor)) {
                        Restore-PlaneHook -Reason 'plane-divisor-changed' | Out-Null
                    }

                    if (-not $script:PlaneHookActive -and
                        [DateTime]::UtcNow -ge $script:NextPlaneInstallUtc) {
                        $script:NextPlaneInstallUtc = [DateTime]::UtcNow.AddSeconds(1)
                        [void](Install-PlaneHook -Divisor $control.PlaneDivisor)
                    }
                }

                # ---- selective world PSSM rate; VehicleShadowTex stays full-rate ----
                if (-not $control.ShadowDesired) {
                    if ($script:ShadowHookActive) {
                        Restore-ShadowHook -Reason 'shadow-native' | Out-Null
                        Write-Host '[BeamOpt] SHADOW NATIVE'
                    }
                }
                else {
                    if ($script:ShadowHookActive -and
                        $script:ShadowActiveDivisor -ne $control.ShadowDivisor) {
                        Restore-ShadowHook -Reason 'shadow-rate-changed' | Out-Null
                    }

                    if (-not $script:ShadowHookActive -and
                        [DateTime]::UtcNow -ge $script:NextShadowInstallUtc) {
                        $script:NextShadowInstallUtc = [DateTime]::UtcNow.AddSeconds(1)
                        [void](Install-ShadowHook -Divisor $control.ShadowDivisor)
                    }
                }

                # ---- PSSM 6.0 fast path ----
                if (-not $control.Pssm6Desired) {
                    if ($script:Pssm6Active) {
                        Restore-Pssm6Patch -Reason 'pssm6-native' | Out-Null
                        Write-Host '[BeamOpt] PSSM 6.0 OFF'
                    }
                }
                elseif (-not $script:Pssm6Active -and
                    [DateTime]::UtcNow -ge $script:NextPssm6InstallUtc) {
                    $script:NextPssm6InstallUtc=[DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-Pssm6Patch)
                }

                # ---- world caster mask 0x100 ----
                if (-not $control.CasterDesired) {
                    if ($script:CasterActive) {
                        Restore-CasterPatch -Reason 'caster-native' | Out-Null
                        Write-Host '[BeamOpt] CASTER MASK NATIVE 0x300'
                    }
                }
                elseif (-not $script:CasterActive -and
                    [DateTime]::UtcNow -ge $script:NextCasterInstallUtc) {
                    $script:NextCasterInstallUtc=[DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-CasterPatch)
                }

                # ---- optional 3-split PSSM ----
                if (-not $control.Split3Desired) {
                    if ($script:Split3Active) {
                        Restore-Split3Patch -Reason 'split4-native' | Out-Null
                        Write-Host '[BeamOpt] PSSM SPLITS NATIVE 4'
                    }
                }
                elseif (-not $script:Split3Active -and
                    [DateTime]::UtcNow -ge $script:NextSplit3InstallUtc) {
                    $script:NextSplit3InstallUtc=[DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-Split3Patch)
                }
            }
        }
        else {
            if ($script:HookActive) { Restore-Hook -Reason 'control-missing' | Out-Null }
            if ($script:PlaneHookActive) { Restore-PlaneHook -Reason 'control-missing' | Out-Null }
            if ($script:ShadowHookActive) { Restore-ShadowHook -Reason 'control-missing' | Out-Null }
            if ($script:Split3Active) { Restore-Split3Patch -Reason 'control-missing' | Out-Null }
            if ($script:CasterActive) { Restore-CasterPatch -Reason 'control-missing' | Out-Null }
            if ($script:Pssm6Active) { Restore-Pssm6Patch -Reason 'control-missing' | Out-Null }
        }

        if ([DateTime]::UtcNow -ge $nextValidation) {
            $nextValidation = [DateTime]::UtcNow.AddSeconds(1)

            if ($script:HookActive) {
                $valid = Validate-ActiveHook
                if (-not $valid -and $control -and
                    ($control.MirrorDesired -or $control.DynamicDesired) -and
                    [DateTime]::UtcNow -ge $script:NextCubeInstallUtc) {
                    $script:Rebuilds++
                    $script:NextCubeInstallUtc = [DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-Hook `
                        -MirrorDesired $control.MirrorDesired `
                        -MirrorDivisor $control.MirrorDivisor `
                        -MirrorAutoViewEnabled $control.MirrorAutoViewEnabled `
                        -DynamicDesired $control.DynamicDesired `
                        -DynamicDivisor $control.DynamicDivisor)
                }
            }

            if ($script:PlaneHookActive) {
                $valid = Validate-PlaneHook
                if (-not $valid -and $control -and $control.PlaneDesired -and
                    [DateTime]::UtcNow -ge $script:NextPlaneInstallUtc) {
                    $script:PlaneRebuilds++
                    $script:NextPlaneInstallUtc = [DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-PlaneHook -Divisor $control.PlaneDivisor)
                }
            }

            if ($script:ShadowHookActive) {
                $valid = Validate-ShadowHook
                if (-not $valid -and $control -and $control.ShadowDesired -and
                    [DateTime]::UtcNow -ge $script:NextShadowInstallUtc) {
                    $script:ShadowRebuilds++
                    $script:NextShadowInstallUtc = [DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-ShadowHook -Divisor $control.ShadowDivisor)
                }
            }

            if ($script:Pssm6Active) {
                $valid = Validate-Pssm6Patch
                if (-not $valid -and $control -and $control.Pssm6Desired -and
                    [DateTime]::UtcNow -ge $script:NextPssm6InstallUtc) {
                    $script:NextPssm6InstallUtc=[DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-Pssm6Patch)
                }
            }

            if ($script:CasterActive) {
                $valid = Validate-CasterPatch
                if (-not $valid -and $control -and $control.CasterDesired -and
                    [DateTime]::UtcNow -ge $script:NextCasterInstallUtc) {
                    $script:NextCasterInstallUtc=[DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-CasterPatch)
                }
            }

            if ($script:Split3Active) {
                $valid = Validate-Split3Patch
                if (-not $valid -and $control -and $control.Split3Desired -and
                    [DateTime]::UtcNow -ge $script:NextSplit3InstallUtc) {
                    $script:NextSplit3InstallUtc=[DateTime]::UtcNow.AddSeconds(1)
                    [void](Install-Split3Patch)
                }
            }
        }

        if ([DateTime]::UtcNow -ge $nextStatus) {
            $nextStatus = [DateTime]::UtcNow.AddSeconds(2)
            Write-BridgeStatus
        }

        if ([DateTime]::UtcNow -ge $nextConsoleStatus) {
            $nextConsoleStatus = [DateTime]::UtcNow.AddSeconds(5)
            Update-ShadowCounters

            $m = if ($script:HookActive -and $script:MirrorThrottleActive) { "1/$($script:ActiveMirrorDivisor)" } else { 'native' }
            $d = if ($script:HookActive -and $script:DynamicThrottleActive) { "1/$($script:ActiveDynamicDivisor)" } else { 'native' }
            $pl = if ($script:PlaneHookActive) { "1/$($script:PlaneActiveDivisor)" } else { 'native' }
            $sh = if ($script:ShadowHookActive) { "1/$($script:ShadowActiveDivisor)" } else { 'native' }
            $p6 = if ($script:Pssm6Active) { '6.0' } else { 'off' }
            $cm = if ($script:CasterActive) { '0x100' } else { '0x300' }
            $sp = if ($script:Split3Active) { '3' } else { '4' }

            Write-Host ("[BeamOpt] mirrors={0}({1}) dynamic={2} planes={3} shadows={4} worldCalls={5}/{6} pssm6={7} caster={8} splits={9}" -f `
                $m,$script:MirrorCount,$d,$pl,$sh,$script:ShadowFullCalls,$script:ShadowTotalCalls,$p6,$cm,$sp)
        }

        if (-not $script:ControlPath -and
            ([DateTime]::UtcNow - $script:LastWaitingPrintUtc).TotalSeconds -ge 5) {
            $script:LastWaitingPrintUtc = [DateTime]::UtcNow
            $rootsText = if (@($script:LastSearchRoots).Count -gt 0) {
                (@($script:LastSearchRoots) -join '; ')
            } else { '<no existing candidate roots found yet>' }
            Write-Host "[BeamOpt] waiting for control file. Search roots: $rootsText"
        }

        Start-Sleep -Milliseconds 100
    }
}
finally {
    Write-Host ''
    Write-Host '[BeamOpt] shutting down; restoring all hooks...'

    $shadowOk = Restore-ShadowHook -Reason 'bridge-exit'
    $splitOk = Restore-Split3Patch -Reason 'bridge-exit'
    $casterOk = Restore-CasterPatch -Reason 'bridge-exit'
    $pssm6Ok = Restore-Pssm6Patch -Reason 'bridge-exit'
    $planeOk = Restore-PlaneHook -Reason 'bridge-exit'
    $cubeOk = Restore-Hook -Reason 'bridge-exit'
    $allOk = ($shadowOk -and $splitOk -and $casterOk -and $pssm6Ok -and $planeOk -and $cubeOk)

    if ($script:StatusPath) {
        try {
            $script:StatusSequence++
            $payload = [ordered]@{
                protocol = 5
                sequence = [Int64]$script:StatusSequence
                helperOnline = $false
                build = 'pattern-scan; baseline 0.39.4.0.20972 Win64'
                pid = 0
                bridgePid = [int]$PID
                mirror = [ordered]@{ active=$false; divisor=0; mirrorCount=0; lastError=$(if($cubeOk){'bridge stopped cleanly'}else{[string]$script:LastError}) }
                dynamic = [ordered]@{ active=$false; divisor=0; objectCount=0; lastError=$(if($cubeOk){'bridge stopped cleanly'}else{[string]$script:LastError}) }
                plane = [ordered]@{ active=$false; divisor=0; objectCount=0; lastError=$(if($planeOk){'bridge stopped cleanly'}else{[string]$script:PlaneLastError}) }
                shadow = [ordered]@{ active=$false; divisor=0; totalCalls=0; fullCalls=0; vehicleFullRate=$false; lastError=$(if($shadowOk){'bridge stopped cleanly'}else{[string]$script:ShadowLastError}) }
                pssm6 = [ordered]@{ active=$false; value=0; lastError=$(if($pssm6Ok){'bridge stopped cleanly'}else{[string]$script:Pssm6LastError}) }
                caster = [ordered]@{ active=$false; mask='0x300'; lastError=$(if($casterOk){'bridge stopped cleanly'}else{[string]$script:CasterLastError}) }
                split3 = [ordered]@{ active=$false; splitCount=4; lastError=$(if($splitOk){'bridge stopped cleanly'}else{[string]$script:Split3LastError}) }
                utc = [DateTime]::UtcNow.ToString('o')
            }
            [IO.File]::WriteAllText(
                $script:StatusPath,
                ($payload | ConvertTo-Json -Depth 7),
                [Text.UTF8Encoding]::new($false))
        } catch { }
    }

    if ($allOk) {
        Write-Host '[BeamOpt] all native hooks restored.'
    } else {
        Write-Warning 'One or more hooks were not verified as restored. Exit BeamNG before continuing.'
    }
}
